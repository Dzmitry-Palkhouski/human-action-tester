# Human Action Tester

HAT runs browser QA scenarios with OS keyboard and mouse events and uses screenshots for verification. It saves session JSON and can generate Word reports.

## Windows setup

Open this folder in an interactive Windows session with Edge installed. From PowerShell:

```powershell
python -m pip install -r requirements.txt
$env:PYTHONPATH = "src"
python -m hat.cli run --help
```

Supply your own flow and executable plan. See [flow format](docs/02-test-flow-format.md) and [architecture](docs/04-architecture.md). With a signed-in GitHub Copilot CLI and an available vision model, set `$env:HAT_COPILOT_IMAGE = "--attachment"` if your CLI documents that flag.

```powershell
python -m hat.cli run --flow path/to/test.flow.md --plan path/to/test.plan.json --out-dir reports/local --browser edge --perceiver copilot --model YOUR_VISION_MODEL
```

For interactive perception, use `--perceiver host`. Keep the Windows desktop unlocked and leave mouse and keyboard input to HAT during a run.
