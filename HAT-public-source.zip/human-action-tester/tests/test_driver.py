from hat.driver import BROWSERS, DryRunDriver, TerminalRunner


def test_dry_run_records_intents_without_side_effects():
    drv = DryRunDriver()
    drv.click(350, 343)
    drv.tripleclick(500, 56)
    drv.key("Return")
    drv.type("hello")
    drv.scroll(0, 3)
    drv.activate("Google Chrome")
    drv.screenshot("/tmp/x.png", region="0,33,1470,825")
    assert drv.intents == [
        "had click 350 343",
        "had tripleclick 500 56",
        "had key Return",
        "had type 'hello'",
        "had scroll 0 3",
        "osascript activate 'Google Chrome'",
        "screencapture -x -R0,33,1470,825 /tmp/x.png",
    ]


def test_dry_run_prepare_stage_minimises_everything_first():
    drv = DryRunDriver()
    drv.prepare_stage("chrome", bounds="0, 33, 1470, 858")
    drv.prepare_stage("safari")
    assert drv.intents[0] == "prepare_stage: minimise ALL windows of every visible app"
    joined = "\n".join(drv.intents)
    assert "prepare_stage[chrome]: activate Google Chrome" in joined
    assert "new incognito window" in joined
    assert "prepare_stage[safari]: activate Safari" in joined


def test_prepare_stage_rejects_unknown_browser():
    try:
        DryRunDriver().prepare_stage("netscape")
    except ValueError as e:
        assert "unknown browser" in str(e)
    else:
        raise AssertionError("expected ValueError")


def test_browser_registry_covers_expected_targets():
    assert set(BROWSERS) >= {"chrome", "edge", "brave", "safari"}
    assert BROWSERS["edge"]["kind"] == "chromium"
    assert BROWSERS["safari"]["kind"] == "webkit"


def test_terminal_runner_escapes_applescript():
    escaped = TerminalRunner._as('say "hi" \\ done')
    assert escaped == '"say \\"hi\\" \\\\ done"'


def test_dry_run_chrome_url_returns_none():
    assert DryRunDriver().chrome_front_url() is None


def test_platform_driver_protocol_conformance():
    from hat.driver import DryRunDriver, PlatformDriver
    from hat.driver_mac import MacDriver
    assert isinstance(DryRunDriver(), PlatformDriver)
    assert isinstance(MacDriver(), PlatformDriver)   # no side effects until methods run


def test_windows_driver_conforms_and_guards():
    from hat.driver import PlatformDriver
    from hat.driver_win import WindowsDriver, DriverError, VK
    drv = WindowsDriver(browser="chrome")
    assert isinstance(drv, PlatformDriver)          # the contract holds
    assert VK["return"] == 0x0D and VK["ctrl"] == 0x11
    try:
        drv.click(10, 10)
        raised = False
    except DriverError:
        raised = True                                # on non-Windows: loud guard
    import sys
    if sys.platform != "win32":
        assert raised
    try:
        WindowsDriver(browser="netscape")
        assert False, "unknown browser must raise"
    except ValueError:
        pass


def test_windows_ie_browser_supported():
    from hat.driver import PlatformDriver
    from hat.driver_win import BROWSER_EXES, WindowsDriver
    assert "ie" in BROWSER_EXES
    drv = WindowsDriver(browser="ie")
    assert isinstance(drv, PlatformDriver)


def test_windows_driver_poc_improvements():
    import hat.driver_win as W
    from hat.driver import PlatformDriver

    # P1: IE Mode launch flags (POC-proven) — exe lookup stubbed (non-Windows)
    drv = W.WindowsDriver(browser="edge", ie_mode=True)
    assert isinstance(drv, PlatformDriver)
    drv._browser_exe = lambda: "msedge.exe"
    args = drv._launch_args("https://legacy.internal/")
    assert "--ie-mode-force" in args
    assert "--internet-explorer-integration=iemode" in args
    assert "--no-service-autorun" in args and "--disable-sync" in args
    # normal edge: no IE flags
    plain = W.WindowsDriver(browser="edge")
    plain._browser_exe = lambda: "msedge.exe"
    a2 = plain._launch_args("https://x/")
    assert "--ie-mode-force" not in a2
    # ie_mode guard
    try:
        W.WindowsDriver(browser="chrome", ie_mode=True)
        assert False
    except ValueError:
        pass

    # P6: window wait is POC-proven 45s
    assert W.WINDOW_WAIT_S == 45

    # P2/P3/P4: popup/focus/teardown surface exists on the protocol
    for name in ("windows", "target", "ensure_focus", "stop"):
        assert hasattr(drv, name)
    assert isinstance(W.WindowsDriver(browser="ie"), PlatformDriver)
