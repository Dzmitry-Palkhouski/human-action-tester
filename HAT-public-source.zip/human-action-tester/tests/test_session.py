from hat.session import (Session, StepRecord, format_duration, now_iso,
                         parse_iso)


def make_session(verdicts):
    s = Session(test_case={"id": "T-1"}, steps=[
        StepRecord(n=i + 1, title=f"step {i + 1}", verdict=v)
        for i, v in enumerate(verdicts)
    ])
    return s


def test_overall_verdict_priority():
    assert make_session(["PASS", "PASS"]).overall_verdict == "PASS"
    assert make_session(["PASS", "INCONCLUSIVE"]).overall_verdict == "INCONCLUSIVE"
    assert make_session(["PASS", "INCONCLUSIVE", "FAIL"]).overall_verdict == "FAIL"
    assert make_session(["PENDING"]).overall_verdict == "PENDING"
    assert make_session(["PASS", "PENDING"]).overall_verdict == "PENDING"
    assert make_session([]).overall_verdict == "PENDING"


def test_counts():
    c = make_session(["PASS", "FAIL", "INCONCLUSIVE", "PENDING"]).counts()
    assert c == {"pass": 1, "fail": 1, "inconclusive": 1, "pending": 1}


def test_roundtrip(tmp_path):
    s = make_session(["PASS", "FAIL"])
    s.summary = "one defect"
    p = tmp_path / "x.session.json"
    s.save(p)
    loaded = Session.load(p)
    assert loaded.steps[1].verdict == "FAIL"
    assert loaded.summary == "one defect"
    assert loaded.overall_verdict == "FAIL"


def test_to_report_dict_shape():
    d = make_session(["PASS"]).to_report_dict()
    assert set(d) == {"test_case", "steps", "overall_verdict", "summary",
                      "total_duration_s"}


def test_format_duration():
    assert format_duration(12.34) == "12.3 s"
    assert format_duration(59.9) == "59.9 s"
    assert format_duration(63) == "1 m 03 s"
    assert format_duration(780) == "13 m 00 s"
    assert format_duration(3725) == "1 h 02 m"
    assert format_duration(None) == "—"
    assert format_duration(-5) == "—"


def test_total_duration_from_recorded_stamps():
    s = make_session(["PASS", "PASS"])
    s.created_at = "2026-11-04T18:00:00"
    s.steps[0].recorded_at = "2026-11-04T18:00:12"
    s.steps[1].recorded_at = "2026-11-04T18:00:30"   # out-of-order-safe: max()
    assert s.total_duration_s == 30.0


def test_total_duration_none_without_stamps():
    assert make_session(["PASS"]).total_duration_s is None
    s = make_session(["PASS"])
    s.created_at = ""
    s.steps[0].recorded_at = "2026-11-04T18:00:12"
    assert s.total_duration_s is None


def test_roundtrip_preserves_timing(tmp_path):
    s = make_session(["PASS"])
    s.created_at = "2026-11-04T18:00:00"
    s.steps[0].recorded_at = "2026-11-04T18:00:05"
    s.steps[0].duration_s = 5.0
    p = tmp_path / "t.session.json"
    s.save(p)
    loaded = Session.load(p)
    assert loaded.created_at == "2026-11-04T18:00:00"
    assert loaded.steps[0].duration_s == 5.0
    assert loaded.total_duration_s == 5.0
