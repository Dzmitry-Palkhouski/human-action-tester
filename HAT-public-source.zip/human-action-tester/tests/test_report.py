import zipfile

from hat.report import build_report
from hat.session import Session, StepRecord
from PIL import Image


def make_shot(path, w=120, h=80, color=(30, 90, 200)):
    Image.new("RGB", (w, h), color=color).save(path)


def make_session():
    return Session(
        test_case={"id": "R-1", "title": "report test", "target": "https://x",
                   "browser": "chrome", "machine": "mac", "executed_by": "driver",
                   "data_row": "row 1", "date": "2026-11-04",
                   "started": "10:00", "finished": "10:05"},
        steps=[
            StepRecord(n=1, title="open", action="click", input="url",
                       expected="page loads", actual="page loaded",
                       verdict="PASS", evidence="url bar", screenshot="s1.png"),
            StepRecord(n=2, title="submit", action="click login", input="creds",
                       expected="error shown", actual="no error",
                       verdict="FAIL", evidence="see shot", screenshot="s2.png"),
        ],
        summary="one failure",
    )


def test_report_generates_valid_docx(tmp_path):
    shots = tmp_path / "shots"
    shots.mkdir()
    for i, name in enumerate(("s1.png", "s2.png")):
        make_shot(shots / name, color=(30 + i * 40, 90, 200))
    out = tmp_path / "report.docx"
    build_report(make_session().to_report_dict(), shots, out)
    assert out.exists()
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        assert "word/document.xml" in names
        assert sum(1 for n in names if n.startswith("word/media/")) == 2
        xml = z.read("word/document.xml").decode("utf-8")
    assert "Step 1 — open" in xml
    assert "Step 2 — submit" in xml
    assert "OVERALL VERDICT: FAIL" in xml        # any FAIL → overall FAIL
    assert "Execution Summary" in xml
    assert "1 failed" in xml.replace("&#8211;", "-") or "failed" in xml


def test_missing_screenshot_is_marked_not_fatal(tmp_path):
    s = make_session()
    s.steps[1].screenshot = "gone.png"
    out = tmp_path / "report2.docx"
    build_report(s.to_report_dict(), tmp_path, out)
    with zipfile.ZipFile(out) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    assert "screenshot missing" in xml


def test_verdict_colors_present(tmp_path):
    shots = tmp_path / "shots"
    shots.mkdir()
    make_shot(shots / "s1.png", color=(10, 90, 200))
    make_shot(shots / "s2.png", color=(60, 90, 200))
    out = tmp_path / "report3.docx"
    build_report(make_session().to_report_dict(), shots, out)
    with zipfile.ZipFile(out) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    assert "E2F0E4" in xml       # PASS shading
    assert "FBE4E0" in xml       # FAIL shading


def test_total_time_fallback_to_started_finished_window():
    from hat.report import _total_execution_time
    payload = {
        "test_case": {"started": "17:52", "finished": "18:05"},
        "steps": [],
    }
    assert _total_execution_time(payload) == 780.0
    payload["test_case"]["started"] = "23:58"
    payload["test_case"]["finished"] = "00:03"
    assert _total_execution_time(payload) == 300.0   # crossed midnight


def test_total_time_prefers_measured_value_then_sum():
    from hat.report import _total_execution_time
    assert _total_execution_time({"total_duration_s": 9}) == 9.0
    payload = {"steps": [{"duration_s": 4}, {"duration_s": 6}]}
    assert _total_execution_time(payload) == 10.0
    assert _total_execution_time({"steps": [{"duration_s": 4}]}) == 4.0
    assert _total_execution_time({"steps": [{"duration_s": 4}, {}]}) is None


def test_no_time_data_omits_total_line(tmp_path):
    s = make_session()
    s.test_case.pop("started"), s.test_case.pop("finished")
    out = tmp_path / "r.docx"
    build_report(s.to_report_dict(), tmp_path, out)
    with zipfile.ZipFile(out) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    assert "Total execution time" not in xml
    assert "Duration" in xml                     # row still present, shows "—"
