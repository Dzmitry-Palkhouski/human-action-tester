"""HARD LIMIT regression test: the tool must never use accessibility-tree
interaction with web pages. Only real input events, screenshots/vision,
browser-chrome state (URL, window title, bounds) and OS window management.

If this test fails, page-level automation crept back in — remove it.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

FORBIDDEN = (
    "hat_axpress",     # AXPress on web elements (removed after user set the limit)
    "hat_axfind",      # AX-tree state reads of web pages
    "entire contents", # full page-tree enumeration
    "AXPress",         # pressing page elements via accessibility
)

WINDOW_LEVEL_OK = (
    "AXMinimized",     # minimise/restore windows (OS window management)
    "AXTitle",         # window title (chrome, not page content)
    "AXRaise",         # raise a window
)


def test_no_page_level_accessibility_automation():
    offenders = []
    for base in ("src", "poc", "flows", "data"):
        for p in (ROOT / base).rglob("*"):
            if p.suffix not in (".py", ".sh", ".md", ".swift", ".json"):
                continue
            text = p.read_text(encoding="utf-8", errors="ignore")
            for needle in FORBIDDEN:
                if needle in text:
                    offenders.append(f"{p.relative_to(ROOT)}: {needle}")
    assert not offenders, (
        "HARD LIMIT violated — page-level accessibility automation found in:\n"
        + "\n".join(offenders)
        + "\nDrive pages ONLY with real input events (bin/had) + screenshots."
    )


def test_window_level_ax_is_documented_as_window_management_only():
    text = (ROOT / "src" / "hat" / "window.py").read_text(encoding="utf-8")
    assert "AXMinimized" in text      # window management usage is allowed
    doc = (ROOT / "docs" / "04-architecture.md").read_text(encoding="utf-8")
    assert "HARD LIMIT" in doc and "never worked around" in doc
