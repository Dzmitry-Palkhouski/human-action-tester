import json
import threading

from hat.perceiver import HostFilePerceiver, parse_percent_point


def test_host_file_roundtrip(tmp_path):
    p = HostFilePerceiver(tmp_path, timeout_s=10)
    got = {}

    def fake_host():
        import time
        d = tmp_path / "perceive"
        for _ in range(40):
            # like the real `perceive pending`: skip answered requests
            reqs = [r for r in sorted(d.glob("req-*.json"))
                    if not (d / r.name.replace("req-", "ans-")).exists()]
            if reqs:
                r = json.loads(reqs[0].read_text())
                (d / f"ans-{r['id']}.json").write_text(
                    json.dumps({"id": r["id"], "text": "x=50.0%, y=10.0%"}))
                got["q"] = r["question"]
                return
            time.sleep(0.1)

    t = threading.Thread(target=fake_host)
    t.start()
    ans = p.ask(tmp_path / "img.png", "where is the button?")
    t.join()
    assert ans == "x=50.0%, y=10.0%"
    assert got["q"] == "where is the button?"
    # second request gets a new id and the same protocol
    t = threading.Thread(target=fake_host)
    t.start()
    assert p.ask(tmp_path / "img.png", "again?") == "x=50.0%, y=10.0%"
    t.join()


def test_parse_percent_point():
    fx, fy = parse_percent_point("CENTER: x=31.5%, y=5.9%")
    assert abs(fx - 0.315) < 1e-9 and abs(fy - 0.059) < 1e-9
    assert parse_percent_point("x=50%, y=100%") == (0.5, 1.0)
    assert parse_percent_point("NOT_VISIBLE") is None
    assert parse_percent_point("no coords here") is None


def test_copilot_cli_perceiver_command_and_parse(tmp_path, monkeypatch):
    import hat.perceiver as P

    # fake an authenticated copilot binary on PATH
    fake_bin = tmp_path / "copilot"
    fake_bin.write_text("#!/bin/sh\nexit 0\n")
    fake_bin.chmod(0o755)
    monkeypatch.setenv("HAT_COPILOT_BIN", str(fake_bin))
    monkeypatch.setenv("HAT_COPILOT_IMAGE", "--image")

    calls = {}

    def fake_run(cmd, capture_output, text, timeout):
        calls["cmd"] = cmd
        class R:
            returncode = 0
            stdout = "x=50.0%, y=20.0%\n"
            stderr = ""
        return R()
    monkeypatch.setattr("subprocess.run", fake_run)

    per = P.CopilotCliPerceiver(model="claude-sonnet-5.5")
    ans = per.ask(tmp_path / "shot.png", "where is the button?")
    assert ans == "x=50.0%, y=20.0%"
    cmd = calls["cmd"]
    assert cmd[0] == str(fake_bin)
    assert "--model" in cmd and "claude-sonnet-5.5" in cmd
    assert "--image" in cmd and str(tmp_path / "shot.png") in cmd
    assert cmd[-2] == "-p" and "where is the button?" in cmd[-1]


def test_copilot_cli_perceiver_errors_are_clear(tmp_path, monkeypatch):
    import pytest
    import hat.perceiver as P
    monkeypatch.setenv("HAT_COPILOT_BIN", "definitely-not-on-path-xyz")
    with pytest.raises(P.PerceiverError, match="not found on PATH"):
        P.CopilotCliPerceiver()

    fake_bin = tmp_path / "copilot"
    fake_bin.write_text("#!/bin/sh\nexit 0\n")
    fake_bin.chmod(0o755)
    monkeypatch.setenv("HAT_COPILOT_BIN", str(fake_bin))

    def failing(cmd, capture_output, text, timeout):
        class R:
            returncode = 1
            stdout = ""
            stderr = "boom"
        return R()
    import subprocess
    monkeypatch.setattr(subprocess, "run", failing)
    with pytest.raises(P.PerceiverError, match="copilot CLI failed"):
        P.CopilotCliPerceiver().ask(tmp_path / "x.png", "q?")
