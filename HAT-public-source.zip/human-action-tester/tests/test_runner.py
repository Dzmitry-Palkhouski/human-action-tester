import zipfile

from PIL import Image

from hat.flow import parse_flow
from hat.runner import RunEngine


class FakeDriver:
    """Records calls; window at (0,33) size 1470x825 like the real stage.
    Popup support: target() switches bounds (perception math follows)."""
    def __init__(self, tmp):
        self.calls = []
        self.tmp = tmp
        self._bounds = (0, 33, 1470, 825)
        self.focus_fail = False
        self.stopped = False
        self.popup = {"handle": 2, "title": "Legacy Login Popup",
                      "x": 200, "y": 100, "w": 600, "h": 400}
    def stage0(self): self.calls.append(("stage0",))
    def window_bounds(self): return self._bounds
    def ensure_focus(self):
        self.calls.append(("ensure_focus",))
        if self.focus_fail:
            raise RuntimeError("target window could not be focused")
    def windows(self): return [{"handle": 1, "title": "Main (Incognito)",
                                "x": 0, "y": 33, "w": 1470, "h": 825},
                               self.popup]
    def target(self, t):
        for w in self.windows():
            if t.lower() in w["title"].lower():
                self._bounds = (w["x"], w["y"], w["w"], w["h"])
                self.calls.append(("target", t))
                return True
        return False
    def stop(self):
        self.stopped = True
        self.calls.append(("stop",))
    def screenshot(self, path):
        Image.new("RGB", (100, 60), color=(10, 10, 10)).save(path)
        self.calls.append(("shot", str(path)))
        return path
    def nav(self, url): self.calls.append(("nav", url))
    def click(self, x, y): self.calls.append(("click", x, y))
    def tripleclick(self, x, y): self.calls.append(("tripleclick", x, y))
    def type(self, t): self.calls.append(("type", t))
    def paste(self, t): self.calls.append(("paste", t))
    def key(self, k): self.calls.append(("key", k))


class ScriptedPerceiver:
    """Answers locate questions with fixed %, verify questions from a map."""
    def __init__(self, verify_answer="VERDICT: PASS — looks right"):
        self.verify_answer = verify_answer
        self.questions = []
    def ask(self, image, question):
        self.questions.append(question)
        if "VERDICT" in question:
            return self.verify_answer
        if "CENTER" in question.upper() or "percentages" in question:
            return "x=50.0%, y=20.0%"
        return "NOT_VISIBLE"


FLOW = """---
id: RT-1
title: runner smoke
target: https://example.test
max_attempts: 2
---

## Step 1 — Open and log in
- **Action:** open the app and log in
- **Input:** ${row.email}
- **Expected:** dashboard visible
- **Plan:** nav ${meta.target}; click Email field; paste ${row.email}; key Tab; paste ${row.password}; key Return; wait 1; verify The dashboard is shown

## Step 2 — Verify banner
- **Action:** check banner
- **Expected:** banner visible
- **Plan:** shot; verify The welcome banner is shown
"""


def make_engine(tmp_path, perceiver):
    flow = parse_flow(FLOW)
    drv = FakeDriver(tmp_path)
    row = {"row_id": "1", "email": "qa@example.com", "password": "Secret10!"}
    eng = RunEngine(flow, drv, perceiver, tmp_path / "run",
                    row=row, max_attempts=None)
    return eng, drv


def test_runner_executes_plan_and_passes(tmp_path):
    eng, drv = make_engine(tmp_path, ScriptedPerceiver())
    session = eng.run()
    calls = [c[0] for c in drv.calls]
    assert calls[0] == "stage0"
    assert ("nav", "https://example.test") in drv.calls
    # click located at 50%/20% of the 1470x825 window at (0,33)
    assert ("click", 735, 198) in drv.calls
    assert ("paste", "qa@example.com") in drv.calls
    assert ("paste", "Secret10!") in drv.calls
    assert ("key", "Return") in drv.calls
    verdicts = [s.verdict for s in session.steps]
    assert verdicts == ["PASS", "PASS"]
    assert session.overall_verdict == "PASS"
    assert all(s.attempts == 1 for s in session.steps)


def test_runner_attempts_budget_fails_and_moves_on(tmp_path):
    per = ScriptedPerceiver(verify_answer="VERDICT: FAIL — banner missing")
    eng, drv = make_engine(tmp_path, per)
    session = eng.run()
    s1, s2 = session.steps
    # max_attempts: 2 in the flow front matter
    assert s1.verdict == "FAIL" and s1.attempts == 2
    assert "banner missing" in (s1.actual or "")
    # step 2 still executed — no endless loop, no abort
    assert s2.verdict == "FAIL"
    assert session.overall_verdict == "FAIL"


def test_runner_missing_target_fails_step_not_run(tmp_path):
    class NeverVisible(ScriptedPerceiver):
        def ask(self, image, question):
            self.questions.append(question)
            return "NOT_VISIBLE"
    eng, drv = make_engine(tmp_path, NeverVisible())
    session = eng.run()
    s1 = session.steps[0]
    assert s1.verdict == "FAIL"
    assert "could not locate" in s1.actual
    assert s1.attempts == 2          # budget consumed, then moved on
    assert ("paste", "qa@example.com") not in drv.calls  # never typed past the miss


def test_runner_session_reportable(tmp_path):
    from hat.report import build_report
    eng, drv = make_engine(tmp_path, ScriptedPerceiver())
    session = eng.run()
    out = tmp_path / "r.docx"
    build_report(session.to_report_dict(), eng.shots, out)
    with zipfile.ZipFile(out) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    assert "OVERALL VERDICT: PASS" in xml
    assert "Attempts" in xml


# ── POC-driven improvements ──────────────────────────────────────────────────

def test_focus_gate_runs_before_input_and_fails_step(tmp_path):
    eng, drv = make_engine(tmp_path, ScriptedPerceiver())
    drv.focus_fail = True
    session = eng.run()
    s1 = session.steps[0]
    assert s1.verdict == "FAIL"
    assert "focus gate failed" in s1.actual
    # the gate fired and BLOCKED input entirely — no click ever happened
    gates = [c for c in drv.calls if c[0] == "ensure_focus"]
    assert gates, "focus gate never ran"
    assert not any(c[0] == "click" for c in drv.calls)
    # run completed (no crash) and teardown still ran
    assert drv.stopped


def test_dismiss_primitive_tolerates_absence(tmp_path):
    flow_txt = FLOW.replace(
        "- **Plan:** shot; verify The welcome banner is shown",
        "- **Plan:** dismiss the IE-mode warning bar close button; "
        "shot; verify The welcome banner is shown")
    from hat.flow import parse_flow
    from hat.runner import RunEngine
    drv = FakeDriver(tmp_path)
    per = ScriptedPerceiver()
    eng = RunEngine(parse_flow(flow_txt), drv, per, tmp_path / "run2",
                    row={"row_id": "1", "email": "a@b.c", "password": "x"},
                    max_attempts=None)
    # perceiver says NOT_VISIBLE for the dismiss locate (question has CENTER)
    class NoBar(ScriptedPerceiver):
        def ask(self, image, question):
            if "warning bar" in question:
                return "NOT_VISIBLE"
            return super().ask(image, question)
    eng.perceiver = NoBar()
    session = eng.run()
    assert session.steps[1].verdict == "PASS"     # absence did not fail the step
    # no click for the dismiss target: step 1 has exactly one click (Email)
    assert sum(1 for c in drv.calls if c[0] == "click") == 1


def test_window_primitive_targets_popup_bounds(tmp_path):
    flow_txt = FLOW.replace(
        "- **Plan:** shot; verify The welcome banner is shown",
        "- **Plan:** window Legacy Login; click User name field; "
        "verify The login popup is shown")
    from hat.flow import parse_flow
    from hat.runner import RunEngine
    drv = FakeDriver(tmp_path)
    eng = RunEngine(parse_flow(flow_txt), drv, ScriptedPerceiver(),
                    tmp_path / "run3",
                    row={"row_id": "1", "email": "a@b.c", "password": "x"},
                    max_attempts=None)
    session = eng.run()
    assert ("target", "Legacy Login") in drv.calls
    # 50%/20% of the POPUP (200,100,600,400) = (500, 180), not main-window math
    assert ("click", 500, 180) in drv.calls
    assert session.steps[1].verdict == "PASS"


def test_attempt_varied_locate_hint(tmp_path):
    flow_txt = FLOW.replace(
        "- **Plan:** shot; verify The welcome banner is shown",
        "- **Plan:** click the Policy Administration entry; "
        "verify The login window opened")
    from hat.flow import parse_flow
    from hat.runner import RunEngine
    drv = FakeDriver(tmp_path)

    class FlakyVerify(ScriptedPerceiver):
        def __init__(self):
            super().__init__()
            self.locate_questions = []
            self.failed_once = False
        def ask(self, image, question):
            if "VERDICT" in question:
                if "login window opened" in question and not self.failed_once:
                    self.failed_once = True
                    return "VERDICT: FAIL — nothing opened"
                return "VERDICT: PASS — visible"
            if "percentages" in question:
                self.locate_questions.append(question)
                return "x=10.0%, y=50.0%"
            return "NOT_VISIBLE"
    per = FlakyVerify()
    eng = RunEngine(parse_flow(flow_txt), drv, per, tmp_path / "run4",
                    row={"row_id": "1", "email": "a@b.c", "password": "x"},
                    max_attempts=None)
    session = eng.run()
    s2 = session.steps[1]
    assert s2.verdict == "PASS" and s2.attempts == 2
    qs = [q for q in per.locate_questions if "Policy Administration" in q]
    assert len(qs) == 2                      # one per attempt
    assert "did NOT activate anything" not in qs[0]
    assert "did NOT activate anything" in qs[1]


def test_teardown_default_and_keep_browser(tmp_path):
    eng, drv = make_engine(tmp_path, ScriptedPerceiver())
    eng.run()
    assert drv.stopped                       # default: teardown ran

    eng2, drv2 = make_engine(tmp_path / "kb", ScriptedPerceiver())
    eng2.keep_browser = True
    eng2.run()
    assert not drv2.stopped                  # --keep-browser skips it
