import json
import zipfile

from hat.cli import main

FLOW = """---
id: VTK-001
title: Login smoke
target: https://app.vidukate.ai
dataset: data/vidukate_credentials.csv
data_dictionary: data/data_dictionary.csv
data_selection: purpose == "invalid-credentials"
browser: chrome
---

## Step 1 — Open the application
- **Action:** Click the address bar, type `${meta.target}`, press Return.
- **Input:** `${meta.target}`
- **Expected:** Login page loads.

## Step 2 — Fill the password
- **Action:** Tab to Password, type `${row.password}`.
- **Input:** `${row.password}`
- **Expected:** Masked dots.
"""

EXPLORE_FLOW = """---
id: VTK-002
title: Sign in and reach the course library
mode: explore
target: https://app.vidukate.ai
dataset: data/vidukate_credentials.csv
data_dictionary: data/data_dictionary.csv
data_selection: purpose == "invalid-credentials"
---

## Description
Sign in with `${keychain.vidukate-qa.email}` and reach the library.

## Start
Logged out on the login page of `${meta.target}`.

## End — success criteria
- The user is signed in, avatar shown
- The library lists at least one course card
"""


def write_fixtures(tmp_path):
    (tmp_path / "flow.flow.md").write_text(FLOW, encoding="utf-8")
    data = tmp_path / "data"
    data.mkdir()
    (data / "vidukate_credentials.csv").write_text(
        "row_id,purpose,email,password,expected_outcome\n"
        '1,invalid-credentials,qa@example.com,SuperSecret9,"Login is rejected"\n',
        encoding="utf-8",
    )
    (data / "data_dictionary.csv").write_text(
        "dataset,column,role,description,format,example\n"
        "vidukate_credentials,row_id,meta,Row id,integer,1\n"
        "vidukate_credentials,purpose,meta,Scenario label,text,x\n"
        "vidukate_credentials,password,input,Fake QA password for the form,text,x\n"
        "vidukate_credentials,expected_outcome,expected,Outcome,sentence,x\n",
        encoding="utf-8",
    )
    return tmp_path / "flow.flow.md", data


def test_execute_creates_skeleton_and_masks_password(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    rc = main(["execute", "--flow", str(flow), "--data-dir", str(data),
               "--out-dir", str(tmp_path / "run1")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "OPERATOR CARD" in out and "Step 2" in out
    assert "SuperSecret9" not in out          # masked in cards
    assert "•" in out

    session_file = tmp_path / "run1" / "VTK-001.session.json"
    payload = json.loads(session_file.read_text())
    assert payload["steps"][0]["expected"] == "Login page loads."
    assert "SuperSecret9" not in json.dumps(payload)


def test_execute_browser_param_overrides_flow(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    rc = main(["execute", "--flow", str(flow), "--data-dir", str(data),
               "--browser", "safari", "--out-dir", str(tmp_path / "run_s")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "STAGE 0" in out and "Safari" in out
    payload = json.loads((tmp_path / "run_s" / "VTK-001.session.json").read_text())
    assert "safari" in payload["test_case"]["browser"]


def test_execute_rejects_unknown_browser(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    rc = main(["execute", "--flow", str(flow), "--data-dir", str(data),
               "--browser", "netscape", "--out-dir", str(tmp_path / "run_x")])
    assert rc == 2
    assert "unknown browser" in capsys.readouterr().err


def test_record_updates_step_and_overall(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    main(["execute", "--flow", str(flow), "--data-dir", str(data),
          "--out-dir", str(tmp_path / "run2")])
    session = str(tmp_path / "run2" / "VTK-001.session.json")
    rc = main(["record", "--session", session, "--step", "1",
               "--verdict", "PASS", "--actual", "page loaded",
               "--screenshot", "s1.png"])
    assert rc == 0
    assert "overall=PENDING" in capsys.readouterr().out  # step 2 still pending
    payload = json.loads(open(session).read())
    assert payload["steps"][0]["verdict"] == "PASS"


def test_record_measures_duration_and_report_shows_total(tmp_path, capsys):
    from hat.report import build_report

    flow, data = write_fixtures(tmp_path)
    main(["execute", "--flow", str(flow), "--data-dir", str(data),
          "--out-dir", str(tmp_path / "run_t")])
    session = str(tmp_path / "run_t" / "VTK-001.session.json")
    main(["record", "--session", session, "--step", "1", "--verdict", "PASS",
          "--actual", "ok", "--duration", "12.5", "--screenshot", "s1.png"])
    out = capsys.readouterr().out
    assert "step 1: PASS in 12.5s" in out
    main(["record", "--session", session, "--step", "2", "--verdict", "FAIL",
          "--actual", "bad", "--duration", "7.5", "--screenshot", "s2.png"])

    payload = json.loads(open(session).read())
    assert payload["steps"][0]["duration_s"] == 12.5
    assert payload["total_duration_s"] == 20.0

    out_docx = tmp_path / "report.docx"
    build_report(json.loads(open(session).read()),
                 tmp_path / "run_t" / "screenshots", out_docx)
    with zipfile.ZipFile(out_docx) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    assert "Duration" in xml
    assert "12.5 s" in xml and "7.5 s" in xml
    assert "Total execution time: 20.0 s" in xml


def test_replay_flow_end_to_end(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    for run, verdict2 in (("base", "FAIL"), ("replay", "PASS")):
        main(["execute", "--flow", str(flow), "--data-dir", str(data),
              "--out-dir", str(tmp_path / run)])
        session = str(tmp_path / run / "VTK-001.session.json")
        main(["record", "--session", session, "--step", "1",
              "--verdict", "PASS", "--actual", "ok", "--screenshot", "s1.png"])
        main(["record", "--session", session, "--step", "2",
              "--verdict", verdict2, "--actual", "observed",
              "--screenshot", "s2.png"])
    rc = main(["replay", "--baseline", str(tmp_path / "base" / "VTK-001.session.json"),
               "--session", str(tmp_path / "replay" / "VTK-001.session.json")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "FIXED" in out
    assert "STILL PASSING" in out


def test_explore_execute_prints_brief_and_empty_skeleton(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    (tmp_path / "explore.flow.md").write_text(EXPLORE_FLOW, encoding="utf-8")
    rc = main(["execute", "--flow", str(tmp_path / "explore.flow.md"),
               "--data-dir", str(data), "--out-dir", str(tmp_path / "run_e")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "EXPLORATION BRIEF" in out
    assert "goal-driven mode" in out
    assert "MISSION:" in out and "SUCCESS:" in out
    assert "The library lists at least one course card" in out
    assert "record --add" in out                      # distillation guidance
    assert "${keychain" not in out                    # masked in the brief
    assert "keychain vidukate-qa/email" in out        # labelled, not raw
    payload = json.loads((tmp_path / "run_e" / "VTK-002.session.json").read_text())
    assert payload["steps"] == []                     # no scripted steps
    assert "goal-driven" in payload["test_case"]["mode"]


def test_explore_distillation_via_record_add(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    (tmp_path / "explore.flow.md").write_text(EXPLORE_FLOW, encoding="utf-8")
    main(["execute", "--flow", str(tmp_path / "explore.flow.md"),
          "--data-dir", str(data), "--out-dir", str(tmp_path / "run_d")])
    session = str(tmp_path / "run_d" / "VTK-002.session.json")
    rc = main(["record", "--session", session, "--add",
               "--title", "Open the login page",
               "--action", "typed URL, pressed Return",
               "--expected", "login form shown",
               "--verdict", "PASS", "--actual", "form shown",
               "--duration", "8.0", "--screenshot", "e1.png"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "step 1: PASS in 8.0s" in out
    rc = main(["record", "--session", session, "--add",
               "--title", "Enter credentials and submit",
               "--action", "clicked Email, typed address; Tab; typed password; clicked Login",
               "--expected", "user signed in, avatar shown",
               "--verdict", "PASS", "--actual", "avatar visible",
               "--duration", "14.0", "--screenshot", "e2.png"])
    assert rc == 0
    payload = json.loads(open(session).read())
    assert [s["n"] for s in payload["steps"]] == [1, 2]
    assert payload["steps"][1]["title"] == "Enter credentials and submit"
    assert payload["overall_verdict"] == "PASS"
    assert payload["total_duration_s"] == 22.0


def test_record_add_missing_step_still_errors(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    main(["execute", "--flow", str(flow), "--data-dir", str(data),
          "--out-dir", str(tmp_path / "run_m")])
    session = str(tmp_path / "run_m" / "VTK-001.session.json")
    rc = main(["record", "--session", session, "--step", "99",
               "--verdict", "PASS"])
    assert rc == 2


def test_finish_marks_pending_and_generates_report(tmp_path, capsys):
    from hat.report import build_report
    from PIL import Image

    flow, data = write_fixtures(tmp_path)
    main(["execute", "--flow", str(flow), "--data-dir", str(data),
          "--out-dir", str(tmp_path / "run_i")])
    shots = tmp_path / "run_i" / "screenshots"
    shots.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (120, 80), color=(5, 5, 5)).save(shots / "s1.png")
    Image.new("RGB", (120, 80), color=(90, 5, 5)).save(shots / "s2.png")

    session = str(tmp_path / "run_i" / "VTK-001.session.json")
    main(["record", "--session", session, "--step", "1", "--verdict", "PASS",
          "--actual", "ok", "--duration", "5", "--screenshot", "s1.png"])
    # step 2 never recorded — session interrupted here

    rc = main(["finish", "--session", session,
               "--note", "Session stopped by operator before completion",
               "--shots", str(shots),
               "--out", str(tmp_path / "interrupted.docx")])
    assert rc == 0

    payload = json.loads(open(session).read())
    assert payload["steps"][0]["verdict"] == "PASS"
    assert payload["steps"][1]["verdict"] == "INCONCLUSIVE"
    assert "interrupted" in payload["steps"][1]["actual"].lower()
    assert payload["overall_verdict"] == "INCONCLUSIVE"

    with zipfile.ZipFile(tmp_path / "interrupted.docx") as z:
        xml = z.read("word/document.xml").decode("utf-8")
    assert "INCONCLUSIVE" in xml
    assert "stopped by operator" in xml.lower()


def test_card_shows_attempts_and_record_stores_them(tmp_path, capsys):
    flow, data = write_fixtures(tmp_path)
    rc = main(["execute", "--flow", str(flow), "--data-dir", str(data),
               "--out-dir", str(tmp_path / "run_a")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "ATTEMPTS: 3 maximum" in out

    session = str(tmp_path / "run_a" / "VTK-001.session.json")
    rc = main(["record", "--session", session, "--step", "1",
               "--verdict", "FAIL", "--actual", "not reached",
               "--attempts", "3", "--screenshot", "s1.png"])
    assert rc == 0
    payload = json.loads(open(session).read())
    assert payload["steps"][0]["attempts"] == 3
