import pytest

from hat.data import (DataDictionary, _keychain_cmd, keychain_lookup,
                      load_dataset, mask_keychain_placeholders, mask_value,
                      random_email, random_password, resolve, resolve_step,
                      select_row)

DICT_CSV = """dataset,column,role,description,format,example
creds,row_id,meta,"Row identifier",integer,1
creds,purpose,meta,"Scenario label",short-text,invalid-credentials
creds,email,input,"Email typed into the login form",email,qa@example.com
creds,password,input,"Fake QA password for the login form",free-text,Secret!123
creds,expected_outcome,expected,"What should happen on submit",sentence,"Login rejected"
"""


@pytest.fixture
def dict_file(tmp_path):
    p = tmp_path / "data_dictionary.csv"
    p.write_text(DICT_CSV, encoding="utf-8")
    return p


@pytest.fixture
def dataset_file(tmp_path):
    p = tmp_path / "creds.csv"
    p.write_text(
        "row_id,purpose,email,password,expected_outcome\n"
        '1,invalid-credentials,qa.bot@example.com,Wrong!Pass,"Login is rejected with an error"\n'
        '2,empty-fields,,,,"Validation error shown"\n',
        encoding="utf-8",
    )
    return p


def test_dictionary_roles_and_sensitivity(dict_file):
    d = DataDictionary.load(dict_file)
    assert d.spec("email").role == "input"
    assert d.spec("expected_outcome").role == "expected"
    assert d.is_sensitive("password") is True      # name + description hint
    assert d.is_sensitive("email") is False


def test_prompt_block_teaches_the_llm(dict_file):
    d = DataDictionary.load(dict_file)
    block = d.prompt_block()
    assert "role=input" in block and "role=expected" in block
    assert "creds.password" in block and "Example:" in block


def test_select_row_by_purpose(dataset_file):
    rows = load_dataset(dataset_file)
    row = select_row(rows, 'purpose == "empty-fields"')
    assert row["row_id"] == "2"
    assert select_row(rows, None)["row_id"] == "1"


def test_select_row_bad_expression(dataset_file):
    rows = load_dataset(dataset_file)
    with pytest.raises(ValueError):
        select_row(rows, "purpose ~= nonsense")
    with pytest.raises(ValueError):
        select_row(rows, 'purpose == "no-such-purpose"')


def test_resolve_placeholders():
    meta = {"target": "https://app.vidukate.ai"}
    row = {"email": "qa@example.com"}
    text = "open ${meta.target} and type ${row.email}; env ${env.HOME}; unknown ${nope.x}"
    out = resolve(text, meta, row, env={"HOME": "/tmp"})
    assert "https://app.vidukate.ai" in out
    assert "qa@example.com" in out
    assert "/tmp" in out
    assert "${nope.x}" in out          # unresolvable stays visible


def test_resolve_step_masks_sensitive_values(dict_file):
    d = DataDictionary.load(dict_file)
    row = {"row_id": "1", "email": "qa.bot@example.com",
           "password": "Wrong!Pass", "expected_outcome": "Login is rejected"}
    fields = {
        "action": "type ${row.password}",
        "input": "password ${row.password} for ${row.email}",
        "expected": "${row.expected_outcome}",
    }
    resolved = resolve_step(fields, {"target": "t"}, row, d)
    assert "Wrong!Pass" not in resolved["input"]
    assert "•" * len("Wrong!Pass") in resolved["input"]
    assert "qa.bot@example.com" in resolved["input"]   # non-sensitive stays
    assert resolved["expected"] == "Login is rejected"


def test_random_placeholders():
    e1, e2 = random_email(), random_email()
    p1, p2 = random_password(), random_password()
    assert e1 != e2 and "@example.com" in e1
    assert p1 != p2 and len(p1) >= 10 and p1.startswith("Qa!")
    out = resolve("user ${random.email} pass ${random.password}", {}, {})
    parts = out.split()
    assert "@example.com" in parts[1] and parts[3].startswith("Qa!")
    assert "${random" not in out


def test_mask_value():
    assert mask_value("abc") == "•••"
    assert mask_value("") == ""


def test_keychain_placeholders_masked_in_report_path():
    text = ("type ${keychain.vidukate-qa.email} then Tab then "
            "${keychain.vidukate-qa.password}; also ${meta.target}")
    masked = mask_keychain_placeholders(text)
    assert "vidukate-qa" not in masked.split("keychain")[0]
    assert "${keychain" not in masked
    assert "•••••••• (keychain vidukate-qa/email)" in masked
    assert "•••••••• (keychain vidukate-qa/password)" in masked
    assert "${meta.target}" in masked          # non-secret placeholders intact


def test_keychain_cmd_shape():
    assert _keychain_cmd("vidukate-qa", "email") == [
        "security", "find-generic-password", "-s", "vidukate-qa",
        "-a", "email", "-w"]
    assert _keychain_cmd("solo", None)[2:] == ["-s", "solo", "-w"]


def test_keychain_lookup_missing_item_returns_none(monkeypatch):
    # keychain_lookup imports subprocess inside the function, so a fake module
    # in sys.modules is what it gets
    import sys, types

    class FakeProc:
        returncode = 44
        stdout = ""

    fake_sub = types.SimpleNamespace(
        run=lambda cmd, capture_output, text: FakeProc())
    monkeypatch.setitem(sys.modules, "subprocess", fake_sub)
    assert keychain_lookup("nope", "x") is None


def test_keychain_lookup_found_item(monkeypatch):
    import sys, types

    class FakeProc:
        returncode = 0
        stdout = "RealSecret42\n"

    fake_sub = types.SimpleNamespace(
        run=lambda cmd, capture_output, text: FakeProc())
    monkeypatch.setitem(sys.modules, "subprocess", fake_sub)
    assert keychain_lookup("vidukate-qa", "password") == "RealSecret42"


def test_resolve_step_masks_keychain_placeholders(dict_file):
    d = DataDictionary.load(dict_file)
    row = {"row_id": "1", "email": "qa@example.com", "password": "",
           "expected_outcome": "ok"}
    fields = {
        "action": "type ${keychain.vidukate-qa.email}, Tab, type ${keychain.vidukate-qa.password}",
        "input": "credentials from keychain",
        "expected": "${row.expected_outcome}",
    }
    resolved = resolve_step(fields, {"target": "t"}, row, d)
    assert "keychain vidukate-qa/email" in resolved["action"]   # labelled
    assert "${keychain" not in resolved["action"]               # never raw
    assert resolved["expected"] == "ok"
