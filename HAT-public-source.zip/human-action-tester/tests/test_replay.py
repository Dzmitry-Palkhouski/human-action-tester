from hat.replay import compare, format_table, summary
from hat.session import Session, StepRecord


def sess(verdicts):
    return Session(test_case={"id": "T"}, steps=[
        StepRecord(n=i + 1, title=f"step {i + 1}", verdict=v)
        for i, v in enumerate(verdicts)
    ])


def test_matrix():
    cases = [
        (["FAIL", "PASS"], ["PASS", "PASS"], ["FIXED", "STILL PASSING"]),
        (["PASS"], ["FAIL"], ["REGRESSION"]),
        (["FAIL"], ["FAIL"], ["STILL FAILING"]),
        (["PASS"], ["INCONCLUSIVE"], ["INCONCLUSIVE"]),
        (["FAIL"], ["PENDING"], ["NOT RUN"]),
    ]
    for base_v, rep_v, expected in cases:
        got = [c.outcome for c in compare(sess(base_v), sess(rep_v))]
        assert got == expected, (base_v, rep_v, got)


def test_summary_counts():
    c = compare(sess(["FAIL", "PASS"]), sess(["PASS", "PASS"]))
    assert summary(c) == {"FIXED": 1, "STILL PASSING": 1}


def test_format_table_has_all_outcomes():
    c = compare(sess(["FAIL"]), sess(["PASS"]))
    table = format_table(c)
    assert "FIXED" in table and "Baseline" in table and "step 1" in table
