import json

from hat.window import WindowHandle


def test_handle_roundtrip(tmp_path):
    h = WindowHandle(x=0, y=33, w=1470, h=825)
    h.created_at = "2026-11-04T22:30:00"
    p = tmp_path / "window.json"
    h.save(p)
    loaded = WindowHandle.load(p)
    assert loaded.incognito is True
    assert loaded.title_marker == "(Incognito)"
    assert loaded.bounds == (0, 33, 1470, 858)      # corners for AppleScript
    assert (loaded.w, loaded.h) == (1470, 825)      # size for AX matching
    assert loaded.created_at == "2026-11-04T22:30:00"
    data = json.loads(p.read_text())
    assert data["app"] == "Google Chrome"


def test_handle_load_tolerates_unknown_keys(tmp_path):
    p = tmp_path / "w.json"
    p.write_text(json.dumps({"app": "Google Chrome", "future_field": 1}))
    h = WindowHandle.load(p)
    assert h.app == "Google Chrome"
