from hat.annotations import (annotation_prompt_block, annotation_url,
                             load_page_annotation, page_annotation_path)


def test_naming_rule():
    assert page_annotation_path("https://app.vidukate.ai/login") == \
        "app.vidukate.ai/login.md"
    assert page_annotation_path("https://app.vidukate.ai/") == \
        "app.vidukate.ai/_root.md"
    assert page_annotation_path("https://app.vidukate.ai") == \
        "app.vidukate.ai/_root.md"
    assert page_annotation_path("https://app.vidukate.ai/dashboard") == \
        "app.vidukate.ai/dashboard.md"
    assert page_annotation_path("https://app.vidukate.ai/students/details") == \
        "app.vidukate.ai/students__details.md"
    assert page_annotation_path(
        "https://app.vidukate.ai/sessions/4f8b7c2a-1234-4abe-9cd0-123456789abc"
    ) == "app.vidukate.ai/sessions__*.md"
    assert page_annotation_path(
        "https://app.vidukate.ai/students/42?tab=filters") == \
        "app.vidukate.ai/students__*__filters.md"
    assert page_annotation_path(
        "https://app.vidukate.ai/contentview?studentId="
        "247834e8-7091-7081-9ba3-629f242c54dc") == \
        "app.vidukate.ai/contentview__*.md"
    assert page_annotation_path(
        "https://app.vidukate.ai/contentview?studentId="
        "247834e8-7091-7081-9ba3-629f242c54dc&tab=upload") == \
        "app.vidukate.ai/contentview__*__upload.md"
    assert page_annotation_path(
        "https://app.vidukate.ai:8443/login") == "app.vidukate.ai/login.md"


def test_annotation_url_line(tmp_path):
    app = tmp_path / "app-annotation"
    (app / "app.vidukate.ai").mkdir(parents=True)
    (app / "app.vidukate.ai" / "dashboard.md").write_text(
        "URL: https://app.vidukate.ai/dashboard\n\n# Page: Dashboard",
        encoding="utf-8")
    assert annotation_url(app, "dashboard") == \
        "https://app.vidukate.ai/dashboard"
    assert annotation_url(app, "https://app.vidukate.ai/dashboard") == \
        "https://app.vidukate.ai/dashboard"
    assert annotation_url(app, "missing-page") == ""


def test_load_and_fallback(tmp_path):
    app = tmp_path / "app-annotation"
    (app / "app.vidukate.ai").mkdir(parents=True)
    (app / "app.vidukate.ai" / "login.md").write_text(
        "# Page: Login\nEmail field autofocuses.", encoding="utf-8")
    (app / "app.vidukate.ai" / "sessions__*.md").write_text(
        "# Session detail template", encoding="utf-8")

    assert "autofocuses" in load_page_annotation(
        app, "https://app.vidukate.ai/login")
    assert "template" in load_page_annotation(
        app, "https://app.vidukate.ai/sessions/abc-123-def-456")
    assert load_page_annotation(app, "https://app.vidukate.ai/nowhere") == ""


def test_prompt_block_includes_url(tmp_path):
    app = tmp_path / "app-annotation"
    (app / "app.vidukate.ai").mkdir(parents=True)
    (app / "app.vidukate.ai" / "login.md").write_text("Login page facts",
                                                      encoding="utf-8")
    block = annotation_prompt_block(app, "https://app.vidukate.ai/login")
    assert "PAGE ANNOTATION" in block
    assert "Login page facts" in block
    assert annotation_prompt_block(app, "https://app.vidukate.ai/none") == ""
