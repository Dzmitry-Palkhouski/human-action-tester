from hat.flow import parse_flow

FLOW = """---
id: VTK-001
title: Login smoke
target: https://app.vidukate.ai
dataset: data/vidukate_credentials.csv
data_selection: purpose == "invalid-credentials"
browser: chrome
---

Intro text that is not a step.

## Step 1 — Open the application
- **Action:** Click the address bar, type `${meta.target}`, press Return.
- **Input:** `${meta.target}`
- **Expected:** Login page loads.

## Step 2 — Fill the email
- **Action:** Click the Email field and type `${row.email}`.
- **Input:** `${row.email}`
- **Expected:** Email field shows the address.
- **Note:** Use Tab to reach the password field next.
"""


def test_front_matter():
    flow = parse_flow(FLOW)
    assert flow.meta["id"] == "VTK-001"
    assert flow.meta["target"] == "https://app.vidukate.ai"
    assert flow.meta["data_selection"] == 'purpose == "invalid-credentials"'
    assert flow.id == "VTK-001"


def test_steps_parsed_in_order_with_fields():
    flow = parse_flow(FLOW)
    assert [s.n for s in flow.steps] == [1, 2]
    s1, s2 = flow.steps
    assert s1.title == "Open the application"
    assert "press Return" in s1.action
    assert s1.expected == "Login page loads."
    assert s2.fields["note"].startswith("Use Tab")
    assert "${row.email}" in s2.input


def test_step_without_optional_fields_is_tolerated():
    minimal = """---
id: X-1
title: t
---

## Step 1 — Only action
- **Action:** Do the thing.
- **Expected:** It works.
"""
    flow = parse_flow(minimal)
    assert len(flow.steps) == 1
    assert flow.steps[0].action == "Do the thing."
    assert flow.steps[0].input == ""


def test_heading_variants_and_sorting():
    variant = """---
id: X
---

## Step 2 - Second
- **Action:** b

## Step 1 — First
- **Action:** a
"""
    flow = parse_flow(variant)
    assert [s.n for s in flow.steps] == [1, 2]


EXPLORE = """---
id: VTK-002
title: Sign in and reach the course library
mode: explore
target: https://app.vidukate.ai
---

## Description
Verify a user can sign in and reach the course library.

## Start
Logged out on the login page of `${meta.target}`.

## End — success criteria
- The user is signed in, avatar shown
- The course library lists at least one course card
- The URL is not /login

## Notes
Poll every 20 seconds; the timeout clock starts at upload completion.
"""


def test_explore_mode_parsed():
    flow = parse_flow(EXPLORE)
    assert flow.mode == "explore"
    assert flow.steps == []
    g = flow.goal
    assert g is not None
    assert "sign in and reach" in g.description
    assert "login page" in g.start
    assert len(g.criteria) == 3
    assert g.criteria[0].startswith("The user is signed in")
    assert g.criteria[2] == "The URL is not /login"
    assert "Poll every 20 seconds" in g.notes


def test_mode_inferred_without_explicit_flag():
    text = EXPLORE.replace("mode: explore\n", "")
    flow = parse_flow(text)
    assert flow.mode == "explore"           # goal sections, no steps
    assert parse_flow(FLOW).mode == "scripted"


def test_scripted_flow_has_no_goal():
    assert parse_flow(FLOW).goal is None


def test_max_attempts_default_and_override():
    flow = parse_flow(FLOW)                      # no max_attempts -> default 3
    assert flow.max_attempts == 3
    assert all(s.max_attempts is None for s in flow.steps)

    override = FLOW.replace("browser: chrome\n",
                            "browser: chrome\nmax_attempts: 5\n")
    override += """
## Step 3 — Special step
- **Action:** Try harder.
- **Expected:** Done.
- **Max attempts:** 7
"""
    f2 = parse_flow(override)
    assert f2.max_attempts == 5                  # flow-level override
    assert f2.steps[2].max_attempts == 7         # per-step override wins
    assert f2.steps[0].max_attempts is None      # inherits flow default
