# Output Document Format (Phase 3 design)

The execution report is a Word document (`.docx`) that a person can scroll
through to "replay" the test, and an AI can read back to re-run it (replay
driver). It is produced by `hat report` from the recorded session JSON.

## Document map

| Pages | Content |
|---|---|
| 1 | Title block + test case identification table + "how to read" note |
| 2N, 2N+1 per step | Facts page, then screenshot page |
| last | Execution summary + overall verdict |

## Page 1 — identification

- `Test Execution Report` + `<id> — <title>`
- Table: target URL, browser (with "no automation flags" note), machine,
  executor identity (Human Action Driver, explicitly "no Selenium/Playwright/
  WebDriver/CDP"), dataset row used, date/time window, steps planned.
- Italic note explaining the 2-pages-per-step layout.

## Step facts page (per step)

`Step N — <title>` heading, one-line italic description, then a 2-column table:

| Field | Content |
|---|---|
| Action (human) | The physical action performed, e.g. "click Email field; type …" |
| Input | Data entered (credentials masked) |
| Expected result | The flow's Expected sentence, verbatim |
| Actual result | What the executor observed on screen, in words |
| Evidence | Pointer to what proves it (what the screenshot shows) |
| Duration | Wall-clock time of the step (`—` when not measured) |
| Verdict | PASS (green) / FAIL (red) / INCONCLUSIVE (amber), cell shaded |

## Step screenshot page (per step)

- Caption: `Step N — screen after action`
- Full-width screenshot (aspect preserved), captured immediately after the
  action, before any verdict is decided.

## Final page — execution summary

- Table: Step / Title / Verdict / Duration / Evidence ref, one row per step.
- Counts: `N steps executed: X passed, Y failed, Z inconclusive`.
- `Total execution time: …` — bold line, computed with an honest fallback
  chain: measured total (sum of per-step durations when every step has one,
  else wall-clock from session start to last recorded step) → sum of the
  durations that exist → the test case's logged started/finished window →
  omitted entirely if nothing was measured (never fabricated).
- `OVERALL VERDICT: …` — large, colored, shaded:
  - PASS when every step passed;
  - FAILED when any step failed;
  - INCONCLUSIVE when no step failed but at least one was inconclusive.
- Italic summary paragraph (what the run proved, defects seen).

Timing semantics: a step's duration is stamped by `hat record` — wall-clock
from the previous step's recording (session start for step 1), or an explicit
`--duration` for scripted atomic runs. Omitted in old sessions → `—`.

## Replay contract

Everything the replay driver needs is in the document (and in the session JSON
that generated it): the flow id and dataset row, each step's Action and Input,
and each step's verdict. The replay driver re-executes the same flow after a
fix and compares step verdicts:

| Baseline | Replay | Outcome |
|---|---|---|
| FAIL | PASS | FIXED |
| FAIL | FAIL | STILL FAILING |
| PASS | FAIL | REGRESSION |
| PASS | PASS | STILL PASSING |
| any | INCONCLUSIVE | INCONCLUSIVE |

Masking rule: any input whose data-dictionary description marks it as a
credential appears as `••••••••` (length only) in the report.
