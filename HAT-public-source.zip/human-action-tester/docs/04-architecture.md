# Human Action Tester (HAT) — architecture notes

## HARD LIMIT — real user actions only

**The tester may interact with a web page exclusively through emulated human
input: real keyboard and mouse events (CGEvent) plus screenshots read by a
vision model.** This is a hard limit, never worked around:

- ❌ **Never**: accessibility-tree interaction with web pages — no AXPress on
  page elements (links, buttons, radio buttons), no AXValue/AXTitle reads of
  page content, no `entire contents` page-tree scans. (An earlier helper,
  `hat_axpress`/`hat_axfind`, did exactly this and was removed after the
  user set the limit.)
- ✅ **Always**: clicks, typing, chords, scrolling via `bin/had`; page state
  read from **screenshots** (vision) and from browser-chrome state via
  Chrome's AppleScript dictionary (active-tab URL, window count/bounds,
  title) — the same things a human glances at (address bar, window title).
- Window/app management (create window, set bounds, minimise, raise, hide
  others) is OS/browser-level orchestration and never touches page content;
  it exists because the user explicitly requires a clean single-window stage
  per session.

Every driving problem must be solved within those means. Proven real-user
equivalents for the common blockers:

| Blocker | Real-user solution |
|---|---|
| Options list below the fold | `View → Zoom Out` via the View menu, or `cmd+minus` — real user shortcuts |
| Searchable combobox with options off-screen | click it (caret appears), **type a prefix that exists**, `ArrowDown`, `Return` — keyboard selection works with the list invisible |
| Autofill dropdown covering the form | `Escape` (closes it, focus stays) — then keyboard-only |
| Page won't scroll synthetically | click a neutral spot, then `Page Down` (keyboard scrolling works) |
| Stale element positions | fresh screenshot → re-measure → act; never reuse coordinates from memory |

---

# Implementation Architecture

## The idea in one paragraph

The tester replaces "browser automation framework" with "LLM + human input
devices". An LLM (the *executor*) reads a test flow, performs actions by
posting real keyboard/mouse events at the OS level, observes the screen by
taking screenshots and looking at them (vision), judges each step against the
flow's Expected sentence, and records everything into a session file from
which the Word report is generated. Nothing is injected into the browser, no
WebDriver/CDP session exists, and the browser is a normal instance with the
user's real profile — which is why this works where Selenium/Playwright are
detected or blocked (proven in the POC: bot.sannysoft.com all green).

## Components

```
                 ┌────────────────────────────────────────────────┐
                 │                  LLM executor                  │
                 │  reads flow + dictionary, decides actions,     │
                 │  judges verdicts from screenshots               │
                 └───────┬───────────────────────┬────────────────┘
                         │ DriverBackend          │ Perceiver
                         ▼                        ▼
 ┌─────────────────────────────────┐   ┌───────────────────────────┐
 │ LocalMacDriver (bin/had, swift) │   │ VisionPerceiver           │
 │  click/move/drag/scroll  (CGEvent)│  │  screenshot → vision model │
 │  key/type               (CGEvent)│  │  (analyze_image today; any │
 │ Runner: Terminal do-script       │   │   multimodal LLM via API)  │
 │  (TCC Accessibility inheritance) │   └───────────────────────────┘
 │  screencapture (Screen Recording)│
 │  AppleScript: activate, window   │
 │  bounds, tab URL (Automation)    │
 └─────────────────────────────────┘
          │                    │                    │
          ▼                    ▼                    ▼
   flows/*.flow.md      data/*.csv +         reports/*.docx +
   (what to test)       data_dictionary.csv  sessions/*.session.json
```

### `hat.flow` — flow parsing
Tolerant Markdown parser: front matter (strict), `## Step N — Title` anchors,
`**Label:**` bullets. Produces `Flow` / `Step` objects. Free text is kept
verbatim — the LLM executor reads it; the parser only anchors structure for
bookkeeping, validation and replay.

### `hat.data` — datasets + data dictionary
CSV/XLSX loading, dictionary parsing, row selection (`purpose == "…"`),
placeholder resolution (`${meta.*}`, `${row.*}`, `${env.*}`), credential
masking driven by the dictionary (never hard-coded column names).

### `hat.driver` — Human Action Driver backends
- `LocalMacDriver`: wraps `bin/had` (compiled Swift CGEvent tool), screencapture
  and AppleScript orchestration. **Why the Terminal runner exists:** macOS TCC
  grants Accessibility per *responsible process*. The events must be posted by
  a process whose responsible app holds the grant (Terminal). `Runner.run()`
  executes action commands through `osascript 'tell app "Terminal" to do
  script'` with a done-marker handshake; screenshots and AppleScript queries
  run in-process (Screen Recording and Automation are granted to the host).
- `DryRunDriver`: records every intent, executes nothing — used by tests and
  for `hat plan` (print the commands a flow would run).
- Future: `ComputerUseSdkDriver` (the host's official SDK when enabled),
  Windows/Linux analogues (SendInput/AT-SPI/ydotool).

### `hat.session` — execution recording
One `StepRecord` per step: action, input, expected, actual, verdict, evidence,
screenshot path. Serialises to `*.session.json` (the replay contract, richer
than the docx). Computes the overall verdict: FAIL > INCONCLUSIVE > PASS.

### `hat.report` — docx generation (phase 3 spec, implemented)
python-docx; 2 pages per step + summary page; verdict colors; aspect-preserved
screenshots; masks credential inputs.

### `hat.replay` — replay driver
Loads a baseline session, re-uses its flow + dataset row, and after the new
run emits a per-step comparison (FIXED / STILL FAILING / REGRESSION / STILL
PASSING / INCONCLUSIVE) plus a replay report. Purpose: verify defect fixes and
catch regressions without re-authoring anything.

### `hat.cli` — operator interface
```
hat execute --flow F --out DIR    # create session skeleton, resolve data, print
                                  # operator cards (step-by-step instructions for
                                  # the LLM/human operator driving the machine)
hat report  --session S --shots D --out FILE.docx
hat replay  --baseline S --session S2 [--out FILE.docx]
hat plan    --flow F              # dry-run: show every driver command, no actions
```
`execute` is *operator-assisted* by design: the judgement loop (see the
screenshots, decide verdicts) is the LLM. A fully autonomous `execute --auto`
plugs a `VisionPerceiver` (any multimodal LLM API) into the same loop — the
POC ran exactly this loop with the session LLM as the perceiver.

## The execution loop (what actually happened in the POC)

```
for step in flow.steps:
    resolved  = data.resolve(step)                 # placeholders → concrete values
    card      = operator_card(step, resolved)      # what to do + what to verify
    actions   = driver.plan_from_card(card)        # click/type/key sequences
    driver.run(actions)                            # real OS-level events
    shot      = driver.screenshot()                # screencapture after action
    actual    = perceiver.describe(shot, expected) # "what do you see?"
    verdict   = judge(expected, actual)            # PASS/FAIL/INCONCLUSIVE
    session.record(step, resolved, actual, verdict, shot)
```

Every micro-action is verified before the next one (the POC showed why: an
unfocused omnibox silently swallows typing; the verify-retry loop is not
optional). State queries that do not need vision (address bar URL, window
bounds) use AppleScript — the equivalent of a human glancing at the URL bar.

## Resilience protocol (observe → reason → adapt)

When an action cannot be executed or the screen does not match expectations,
the executor must NOT retry blindly. It takes a full screenshot, studies it,
and adapts — exactly like a person. Real case that shaped this rule: Chrome's
password-manager autofill dropdown opened over the login form when the email
field was clicked, covering the password field and the Login button; clicks
aimed "through" it selected stored-username rows and autofilled wrong values
into the email field — three failed logins before the overlay was noticed.

Rules that follow:

1. **Look before every action** — a screenshot is cheap; a wrong click on an
   overlay is not.
2. **Anything in the way gets dismissed first**: autofill dropdowns and
   popovers close with Escape (focus stays in the field); menus and infobars
   close with their own ✕ or a click on neutral space.
3. **Re-locate targets after any layout change** (infobars shift the page
   down; dropdowns hide controls). Never reuse coordinates from memory.
4. **Verify focus before typing** (focus ring / caret visible on the intended
   field) and **verify content after typing** (field shows the typed value;
   masked fields show the expected number of dots).
5. **Prefer deterministic dismissals** (Escape, Tab-away, clicking a neutral
   area) over precision clicks on small targets like infobar ✕ buttons.
6. **Test profiles should disable autofill** where possible; where not
   (incognito still suggests saved passwords), the Escape-first pattern is
   mandatory around credential fields.

## Credential handling (what to type when the data has none)

Credentials never live in flow files (they are committed) and never appear in
reports (the replay contract must be shareable). The source chain, in order:

1. **Committed fake data** (what the POC used) — `vidukate_credentials.csv`
   with invented values. Perfect for negative paths (invalid login, validation
   errors) and safe to commit because the values are meaningless.
2. **Environment variables** — `${env.QA_EMAIL}` / `${env.QA_PASSWORD}`.
   Right choice for CI. The flow references the name; the runner's
   environment holds the value.
3. **macOS Keychain** — `${keychain.vidukate-qa.email}` /
   `${keychain.vidukate-qa.password}`. The recommended local default:
   `security add-generic-password -s vidukate-qa -a email -w '...'`. The
   executor resolves it at execution time via `hat.data.keychain_lookup`
   (`security find-generic-password -s vidukate-qa -a email -w`); cards,
   sessions and reports only ever show `•••••••• (keychain vidukate-qa/email)`.
   An unresolved item keeps the placeholder visible — a missing credential is
   a loud error, never a silent empty field.
4. **Runtime prompt** — for interactive runs, the operator asks the user once
   and keeps the value in memory for the session.
5. **Self-provisioned test account** — the flow's Stage -1 signs up a
   throwaway user through the UI (vidukate has registration), or — since the
   product is yours — a QA account is seeded in the staging backend and read
   from the keychain.

If literally nothing is available, the suite covers the pre-auth surface and
negative paths only (that is exactly what the POC proved: invalid-credential
rejection is fully testable with no real account).

Entry mechanics: values are **typed** (`had type`), never pasted (no
clipboard residue), live only in the executor process, and are masked by the
data dictionary + keychain rules. One practical trap: password-manager
browser extensions (1Password/Bitwarden) pop autofill over password fields
and fight synthetic typing — use a test browser profile with autofill
disabled, which also keeps QA cookies away from the personal profile.

## Which model executes the tests

The executor does two different jobs, and they have different model
requirements:

1. **Perceiver (hot loop, 5–15 calls per step):** look at a screenshot,
   answer pointed questions ("what text is in the error banner?", "where is
   the Login button, as % of the window?"). This is volume work — a fast,
   cheap multimodal model is the right choice (Gemini Flash-class, GLM-4.6V,
   Qwen-VL-class). Grounding accuracy matters more than reasoning here.
2. **Judge (once per step):** compare the Expected sentence against what was
   observed, write the Actual result, assign PASS/FAIL/INCONCLUSIVE. This
   needs faithful observation and restraint (a weak model rubber-stamps
   PASS). A frontier-tier model (or at minimum a strong mid-tier) is
   recommended; judgment errors are the expensive kind — they hide defects.

Calibration before trusting a perceiver: run it against 5–10 known elements
and require ±3% coordinate accuracy and exact text reads. In the POC the
vision tier read form fields, error banners and detection tables accurately,
but **confabulated a cursor position** when asked about a detail that was not
in the image (screenshots don't include the cursor). Rules that follow:

- Never ask the perceiver about something that can be checked deterministically.
- Prefer deterministic state checks over vision: address bar URL and window
  bounds via AppleScript, screenshot hash-compare to detect "nothing changed",
  PNG pixel-diff for region changes.
- Prefer keyboard-deterministic paths (Tab, Return, triple-click select-all)
  over coordinate clicks wherever the form allows — this removes most
  grounding risk entirely.

Cost profile per step: ~1–2k tokens per screenshot, 5–15 perceiver calls, 1
judge call — a login-smoke-class flow is a few cents on Flash-class
perception even with a frontier judge.

## Stage 0 — deterministic test surface (mandatory)

**Every test session starts by minimising ALL windows of every visible app,
then creating one fresh browser window at fixed bounds.** No exceptions —
this is enforced in `driver.prepare_stage(browser)`:

1. minimise every window of every visible application (System Events via the
   Terminal runner — needs the Accessibility grant Terminal holds);
2. activate the chosen browser (`--browser chrome|edge|brave|safari`) and
   create ONE fresh **incognito** window at fixed bounds;
3. full-screen capture must show exactly that single window before any input
   is sent.

Rationale written in failures: `open -a Chrome` raises Chrome's *previously
key window* — which may be the operator's own work inbox; a new window
created without minimising everything races that raise; and keystrokes aimed
at an overlapped window land in whichever app is actually front (a login
script once typed into a live Zoho inbox this way). A single visible window
at known bounds removes the entire class of z-order and occlusion failures,
and makes every screenshot's coordinate space unambiguous.

## Failure modes and mitigations

| Risk | Mitigation |
|---|---|
| Synthetic events dropped (focus races) | verify-after-every-micro-action loop; atomic multi-action scripts; retry with re-observation |
| Vision misreads coordinates | targets located as % of window + clamped clicks; deterministic keyboard alternatives (Tab/Return) preferred over coordinate clicks |
| Competing windows/profiles | dedicated browser window created by the runner; other windows minimised (orchestration-level AppleScript) |
| User fights the machine during a run | run banner in the report ("machine was hands-off"); runs are short |
| Credential leakage | masking driven by data dictionary roles; secrets never in flow files |

## Why this passes where Selenium/Playwright fail

No `navigator.webdriver`, no CDP attach, no `--enable-automation`, no
DevTools protocol, no injected scripts, real user profile, real GPU, real
input events from the HID tap. Anti-bot pages see a human browser (POC
evidence: bot.sannysoft.com fully green). Legacy apps that crash or lock out
under automation frameworks see nothing unusual because nothing about the
browser changes.
