# Test Flow Format (Phase 2 design)

A test flow is a plain Markdown file (`.flow.md`) that a human can read and an
LLM can execute. The executor is the LLM itself: it reads the flow, performs
the actions through the Human Action Driver (OS-level keyboard/mouse), sees
the screen through screenshots, and records actual results.

There are **two modes**:

1. **Scripted mode** — step-by-step instructions (below). Used when the path
   is known and must be reproduced exactly (regression suites, replays).
2. **Simplified / goal mode** (`mode: explore`) — the flow gives a mission, a
   starting point and an end state with success criteria; the AI navigates
   the application on its own. See the last section.

Design goals:

1. **Human-readable first.** A QA engineer writes the flow in natural language,
   exactly like a manual test case in TestRail/qTest.
2. **Machine-anchored.** A tolerant parser extracts structure (steps, expected
   results, data references) so the runner can build the report skeleton,
   validate data references before execution, and support replay.
3. **No selectors.** Targets are described the way a person would find them
   ("the Login button under the password field"), not with CSS/XPath — the
   driver sees the screen like a person, so the description a person needs is
   the description the driver needs.

## File layout

```
flows/
  vidukate_login_smoke.flow.md     # test flow (this format)
data/
  vidukate_credentials.csv         # input/expected data (rows)
  data_dictionary.csv              # textual interpretation of every column
```

## Flow file structure

```markdown
---
id: VTK-001
title: Login page loads and rejects invalid credentials
target: https://app.vidukate.ai
dataset: data/vidukate_credentials.csv
data_dictionary: data/data_dictionary.csv
data_selection: purpose == "invalid-credentials"
browser: chrome
precondition: Public login page, no session required
---

## Step 1 — Open the application
- **Action:** Click the browser address bar, type `${meta.target}`, press Return.
- **Input:** `${meta.target}`
- **Expected:** The login page loads: a "Login to Vidukate" form with an Email
  field, a Password field, a Remember me checkbox and a Login button.

## Step 2 — Fill the email address
- **Action:** Click the Email field and type `${row.email}`.
- **Input:** `${row.email}` (dataset row `${row.row_id}`)
- **Expected:** The Email field displays the typed address.
```

### Front matter (anchored, parsed strictly)

| Key | Meaning |
|---|---|
| `id` | Test case ID used in the report |
| `title` | Human title |
| `target` | URL the test opens (referenced as `${meta.target}`) |
| `dataset` | Optional CSV/XLSX with input/expected data |
| `data_dictionary` | The dictionary file that explains the dataset columns |
| `data_selection` | Python-ish expression picking dataset row(s); default: first row |
| `browser` | Browser to use (`chrome`, `safari`, `edge`) |
| `precondition` | Plain-language precondition |

### Steps

- One `## Step N — Title` heading per step. `N` defines order.
- Bulleted fields, any order, optional except `Action` and `Expected`:
  - `Action` — what the driver does, in human terms (click/type/press/scroll/read).
  - `Input` — concrete data entering the system (placeholders resolved before run).
  - `Expected` — the observable outcome a person would check. This sentence is
    what the executor compares the screen against; write it visually.
  - `Note` — hints (timing, known flakiness, fallback strategy).

### Placeholder language

| Placeholder | Resolves to |
|---|---|
| `${meta.KEY}` | Front-matter value (e.g. `${meta.target}`) |
| `${row.COLUMN}` | Selected dataset row's column value |
| `${env.NAME}` | Environment variable (never secrets in the flow file; the executor masks values of columns whose dictionary entry marks them sensitive) |

## Simplified mode (goal-driven exploration)

When writing per-step instructions is overkill — early exploration, smoke
coverage of a new area, or the path simply isn't known yet — a flow can
declare a goal instead of steps:

```markdown
---
id: VTK-002
title: Sign in and reach the course library
mode: explore
target: https://app.vidukate.ai
...

## Description
Verify that a user can sign in and reach the course library.

## Start
Logged out, on the login page of ${meta.target} in a clean window;
credentials from ${keychain.vidukate-qa.email} / ${keychain.vidukate-qa.password}.

## End — success criteria
- The user is signed in: no login form is visible, avatar shown
- The course library lists at least one course card
- The URL is on a courses/library route, not /login
```

Rules:

- `mode: explore` selects the mode explicitly; it is also inferred when the
  file has Description/Start/End sections and no `## Step N` headings.
- **End criteria are bullets under `## End — success criteria`** — each one
  must be objectively checkable on screen, because they become the Expected
  text of the distilled steps.
- Placeholders resolve exactly like scripted mode (incl. keychain masking).

### Execution semantics

The executor runs observe → decide one action → act → verify until all
criteria hold at the end state (a ~30-action budget guards against loops;
exceeding it yields INCONCLUSIVE). Dead ends are expected and simply
backtracked — **they are never documented**. When the end state is reached,
the successful path is **distilled into test steps**: segmented by user
intention ("open login page", "enter credentials", "submit", "verify
library"), each recorded with `hat record --add` (title / action / input /
expected-from-criteria / actual / verdict / screenshot from that moment).
The report then shows a clean, human-plausible test — not the search process.
If the goal is not reached, the whole attempt is recorded as one FAIL /
INCONCLUSIVE step plus the missing criteria, and the last screenshot.

The distilled session is a first-class session: it replays (`hat replay`),
and after a fix you can promote the distilled steps into a scripted flow for
the regression suite.

## Data files and the data dictionary

Datasets are CSV (or XLSX, one sheet per dataset, first row = header). The
**data dictionary** is the piece that teaches the LLM how to read and use the
data. One row per column:

| Field | Meaning |
|---|---|
| `dataset` | Which dataset the column belongs to |
| `column` | Column name |
| `role` | `input` / `expected` / `meta` — how the executor must treat it |
| `description` | Plain-language explanation of the column |
| `format` | Expected format (email, integer, free-text, sentence…) |
| `example` | One example value |

Rules the executor follows because of the dictionary:

- `role=input` → value is typed/entered by the driver during the step that
  references it.
- `role=expected` → value is compared against what appears on screen.
- `role=meta` → value is context only (row selection, notes).
- Any column whose name or description marks it a credential (password, PIN,
  token) is **masked in the report** regardless of role.
- `data_selection` picks rows using `purpose` (a `meta` column) — the executor
  reads the dictionary to know `purpose` is the row-selection key.

## Verdicts

| Verdict | Meaning |
|---|---|
| `PASS` | Observed screen matches the step's Expected sentence |
| `FAIL` | Clear mismatch between Expected and Actual |
| `INCONCLUSIVE` | Could not determine (element never appeared, environment issue, driver blocked) — used instead of guessing |

## Why Markdown and not YAML/JSON

The executor is an LLM, so strict machine syntax buys nothing; humans write
flows. Markdown keeps diffs readable in code review, pastes cleanly into test
management tools, and the tolerant parser only needs the anchors (front matter,
`## Step N`, `**Label:**` bullets) — everything else stays free text that the
LLM understands in context.
