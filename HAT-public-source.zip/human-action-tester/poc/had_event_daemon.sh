#!/bin/bash
# had_event_daemon.sh — persistent event dispatcher running INSIDE Terminal
# (which holds the macOS Accessibility grant). Reads one command per line from
# the FIFO and executes it with the had binary. Started ONCE by Stage 0; my
# context writes commands to the FIFO without ever activating Terminal.
H=/Users/dmitriprilepski/.zcode/workspace/d92add43-8be3-483d-95ec-dca611ab71c3/human-action-tester/bin/had
FIFO=/tmp/had_cmds.fifo
[ -p "$FIFO" ] || mkfifo "$FIFO"
echo "DAEMON_READY"
while true; do
  while read -r line; do
    [ -z "$line" ] && continue
    case "$line" in
      echo*) eval "$line" ;;
      *) "$H" $line ;;
    esac
  done < "$FIFO"
  sleep 0.05
done
