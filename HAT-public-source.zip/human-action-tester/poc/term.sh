#!/bin/bash
# term.sh — run a shell command inside Terminal (the Accessibility grant holder).
# Each run: fresh tab, self-closing (tab is closed when the command completes),
# so no Terminal windows accumulate during test runs.
CMD="$*"
rm -f /tmp/had_term.done /tmp/had_term.out

REF=$(osascript -e "tell application \"Terminal\" to do script \"$CMD > /tmp/had_term.out 2>&1; echo __RC__=\$? > /tmp/had_term.done\"")
# REF looks like: "tab 1 of window id 10812"
WINID=$(echo "$REF" | sed -E 's/.*window id ([0-9]+).*/\1/')
TABIDX=$(echo "$REF" | sed -E 's/^tab ([0-9]+).*/\1/')

for i in $(seq 1 240); do
  [ -f /tmp/had_term.done ] && break
  sleep 0.25
done

# self-clean: close all Terminal windows (this runner owns Terminal; each run
# leaves nothing open)
osascript -e 'tell application "Terminal" to close every window' >/dev/null 2>&1 &

if [ -f /tmp/had_term.done ]; then
  cat /tmp/had_term.done
  [ -f /tmp/had_term.out ] && cat /tmp/had_term.out
else
  echo "TERM_TIMEOUT"
  exit 124
fi
