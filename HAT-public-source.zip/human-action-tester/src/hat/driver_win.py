"""Windows PlatformDriver — in-process SendInput, no helper binary, no grants.

Real user input only (HARD LIMIT): SendInput keyboard/mouse, clipboard paste,
per-window capture (PrintWindow). Window management via Win32. Stage 0
launches a dedicated browser process with a UNIQUE temp --user-data-dir —
provably-new window owned by our PID; everything else is minimised.

Lessons encoded here from the Copilot/Windows POC (Archive 3):
- IE Mode is launchable per-run: --ie-mode-force --internet-explorer-
  integration=iemode (its warning bar is dismissed via the runner's
  `dismiss` plan primitive — vision-located, never blind clicks).
- Legacy pages open POPUPS: windows()/target(title) switch the driven
  window; window_bounds/screenshot/nav follow the active target.
- Focus is gated before every input primitive (ensure_focus).
- Runs tear down: process tree killed, temp profile removed.
- Window appearance wait is 45 s (cold Edge + fresh profile).
- Capture is hwnd-based (PrintWindow) — occlusion-safe; screen-grab fallback.

On non-Windows hosts this module imports cleanly and every driver call
raises DriverError — so conformance tests run anywhere.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

IS_WIN = sys.platform == "win32"

if IS_WIN:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
else:  # allow import + conformance tests on any OS
    user32 = kernel32 = gdi32 = None

WINDOW_WAIT_S = 45          # POC-proven: cold Edge + fresh profile is slow
FOCUS_RETRIES = 3


class DriverError(RuntimeError):
    pass


def _require_win():
    if not IS_WIN:
        raise DriverError("WindowsDriver requires Windows (SendInput/win32)")


# ── Win32 structures / constants ─────────────────────────────────────────────
ULONG_PTR = ctypes.c_size_t

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wt.DWORD), ("dy", wt.DWORD), ("mouseData", wt.DWORD),
                ("dwFlags", wt.DWORD), ("time", wt.DWORD),
                ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wt.WORD), ("wScan", wt.WORD), ("dwFlags", wt.DWORD),
                ("time", wt.DWORD), ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wt.DWORD), ("wParamL", wt.WORD), ("wParamH", wt.WORD)]

class _INPUTunion(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wt.DWORD), ("union", _INPUTunion)]

class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG),
                ("biPlanes", wt.WORD), ("biBitCount", wt.WORD),
                ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG),
                ("biClrUsed", wt.DWORD), ("biClrImportant", wt.DWORD)]

class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wt.DWORD * 3)]

INPUT_MOUSE, INPUT_KEYBOARD = 0, 1
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_ABSOLUTE = 0x8000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
PW_RENDERFULLCONTENT = 0x00000002      # needed for Chromium windows
BI_RGB = 0
DIB_RGB_COLORS = 0
SW_MINIMIZE = 6
GWL_EXSTYLE = -20
WS_EX_TOOLWINDOW = 0x00000080
CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
ES_CONTINUOUS, ES_DISPLAY_REQUIRED = 0x80000000, 0x00000002
SM_CXSCREEN, SM_CYSCREEN = 0, 1

VK = {
    "return": 0x0D, "enter": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B,
    "delete": 0x2E, "backspace": 0x08, "space": 0x20,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
    "ctrl": 0x11, "control": 0x11, "shift": 0x10, "alt": 0x12, "win": 0x5B,
    "minus": 0xBD, "equal": 0xBB, "plus": 0xBB,
}
for _i in range(1, 13):
    VK[f"f{_i}"] = 0x70 + _i - 1

MODIF = {"ctrl": 0x11, "control": 0x11, "shift": 0x10,
         "alt": 0x12, "win": 0x5B, "cmd": 0x11}   # cmd → ctrl on Windows

# Per-run IE Mode (POC-proven flags); the warning bar these spawn is handled
# by the runner's `dismiss` primitive with vision-located clicks.
IE_MODE_FLAGS = ["--ie-mode-force", "--internet-explorer-integration=iemode"]

BROWSER_EXES = {
    "chrome": ["chrome.exe",
               r"C:\Program Files\Google\Chrome\Application\chrome.exe",
               r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"],
    "edge": ["msedge.exe",
             r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
             r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"],
    # Real IE11 — Windows Server / LTSC only (Win10 22H2+/Win11: stub → use
    # `--browser edge-ie`). HARD LIMIT: never InternetExplorer.Application COM.
    "ie": ["iexplore.exe",
           r"C:\Program Files\Internet Explorer\iexplore.exe",
           r"C:\Program Files (x86)\Internet Explorer\iexplore.exe"],
}


def _send(*inputs: INPUT) -> None:
    n = len(inputs)
    arr = (INPUT * n)(*inputs)
    sent = user32.SendInput(n, arr, ctypes.sizeof(INPUT))
    if sent != n:
        raise DriverError(f"SendInput delivered {sent}/{n} (blocked? UIPI?)")


def _key_input(vk: int, flags: int, scan: int = 0) -> INPUT:
    i = INPUT(type=INPUT_KEYBOARD)
    i.union.ki = KEYBDINPUT(wVk=vk, wScan=scan, dwFlags=flags)
    return i


def _unicode_input(code: int, down: bool) -> INPUT:
    i = INPUT(type=INPUT_KEYBOARD)
    flags = 0 if down else KEYEVENTF_KEYUP
    i.union.ki = KEYBDINPUT(wVk=0, wScan=code,
                            dwFlags=flags | KEYEVENTF_UNICODE)
    return i


def _mouse_input(flags: int, dx: int = 0, dy: int = 0) -> INPUT:
    i = INPUT(type=INPUT_MOUSE)
    i.union.mi = MOUSEINPUT(dx=dx, dy=dy, dwFlags=flags)
    return i


def _screen_size() -> tuple[int, int]:
    return (user32.GetSystemMetrics(SM_CXSCREEN),
            user32.GetSystemMetrics(SM_CYSCREEN))


def _abs_point(x: int, y: int) -> tuple[int, int]:
    w, h = _screen_size()
    return int(x * 65535 / max(1, w - 1)), int(y * 65535 / max(1, h - 1))


def _enum_windows() -> list[int]:
    found = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)

    def cb(hwnd, _l):
        found.append(hwnd)
        return True
    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return found


def _win_pid(hwnd) -> int:
    pid = wt.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def _win_title(hwnd) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _rect_of(hwnd) -> tuple[int, int, int, int]:
    r = wt.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(r))
    return r.left, r.top, r.right, r.bottom


class WindowsDriver:
    """PlatformDriver on Windows. Stage 0 launches a dedicated browser
    process (unique temp profile) — our window is provably new and owned by
    our PID; everything else is minimised. `target()` switches to popup
    windows of the same process (legacy apps open popups)."""

    def __init__(self, browser: str = "chrome", bounds: tuple = (0, 0, 1470, 900),
                 ie_mode: bool = False):
        if browser not in BROWSER_EXES:
            raise ValueError(f"unknown Windows browser {browser!r}; "
                             f"known: {sorted(BROWSER_EXES)}")
        if ie_mode and browser != "edge":
            raise ValueError("ie_mode requires edge (CLI alias: edge-ie)")
        self.browser = browser
        self.ie_mode = ie_mode
        self.x, self.y, self.w, self.h = bounds
        self.hwnd: int | None = None
        self.proc: subprocess.Popen | None = None
        self.profile_dir: Path | None = None
        if IS_WIN:
            try:
                user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
            except Exception:  # noqa: BLE001 — older Windows
                user32.SetProcessDPIAware()

    # ── launch args (pure — unit-testable) ──────────────────────────────────
    def _launch_args(self, url: str) -> list[str]:
        exe = self._browser_exe()
        if self.browser == "ie":
            return [exe, "-private", url]
        args = [exe, f"--user-data-dir={self.profile_dir}",
                "--no-first-run", "--no-default-browser-check",
                "--no-service-autorun", "--disable-sync",
                f"--window-position={self.x},{self.y}",
                f"--window-size={self.w},{self.h}",
                "--new-window"]
        if self.ie_mode:
            args += IE_MODE_FLAGS
        args.append(url)
        return args

    def _browser_exe(self) -> str:
        for cand in BROWSER_EXES[self.browser]:
            if "\\" in cand and Path(cand).exists():
                return cand
            found = shutil.which(cand)
            if found:
                return found
        raise DriverError(f"{self.browser} executable not found")

    # ── input ───────────────────────────────────────────────────────────────
    def _move(self, x: int, y: int) -> None:
        _require_win()
        ax, ay = _abs_point(x, y)
        _send(_mouse_input(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, ax, ay))

    def ensure_focus(self) -> None:
        """Per-action focus gate (POC lesson): raise if the target cannot be
        brought to the foreground — never send input blind."""
        _require_win()
        for _ in range(FOCUS_RETRIES):
            if self.refocus():
                return
            time.sleep(0.3)
        raise DriverError("target window could not be focused "
                          f"(hwnd={self.hwnd}) — input suppressed")

    def click(self, x: int, y: int) -> None:
        self.ensure_focus()
        self._move(x, y); time.sleep(0.05)
        _send(_mouse_input(MOUSEEVENTF_LEFTDOWN)); time.sleep(0.04)
        _send(_mouse_input(MOUSEEVENTF_LEFTUP))

    def tripleclick(self, x: int, y: int) -> None:
        self.ensure_focus()
        self._move(x, y); time.sleep(0.05)
        for _ in range(3):
            _send(_mouse_input(MOUSEEVENTF_LEFTDOWN)); time.sleep(0.04)
            _send(_mouse_input(MOUSEEVENTF_LEFTUP)); time.sleep(0.05)

    def key(self, chord: str) -> None:
        _require_win()
        self.ensure_focus()
        parts = [p.strip().lower() for p in chord.split("+") if p.strip()]
        mods = [MODIF[p] for p in parts[:-1] if p in MODIF]
        final = parts[-1]
        vk = VK.get(final)
        if vk is None and len(final) == 1:
            vk = ord(final.upper())
        if vk is None:
            raise DriverError(f"unknown key {final!r} in chord {chord!r}")
        for m in mods:
            _send(_key_input(m, 0))
        _send(_key_input(vk, 0)); time.sleep(0.02)
        _send(_key_input(vk, KEYEVENTF_KEYUP))
        for m in reversed(mods):
            _send(_key_input(m, KEYEVENTF_KEYUP))

    def type(self, text: str) -> None:
        """Per-character KEYEVENTF_UNICODE — reliable on Windows."""
        _require_win()
        self.ensure_focus()
        for ch in text:
            code = ord(ch)
            _send(_unicode_input(code, down=True))
            time.sleep(0.015)
            _send(_unicode_input(code, down=False))
            time.sleep(0.02)

    def paste(self, text: str) -> None:
        self.ensure_focus()
        self._set_clipboard(text)
        time.sleep(0.08)
        self.key("ctrl+v")
        time.sleep(0.2)

    def _set_clipboard(self, text: str) -> None:
        _require_win()
        buf = ctypes.create_unicode_buffer(text)
        if not user32.OpenClipboard(None):
            raise DriverError("OpenClipboard failed")
        try:
            user32.EmptyClipboard()
            h = kernel32.GlobalAlloc(GMEM_MOVEABLE, ctypes.sizeof(buf))
            p = kernel32.GlobalLock(h)
            ctypes.memmove(p, buf, ctypes.sizeof(buf))
            kernel32.GlobalUnlock(h)
            user32.SetClipboardData(CF_UNICODETEXT, h)
        finally:
            user32.CloseClipboard()

    # ── focus / windows (popups!) ───────────────────────────────────────────
    def refocus(self) -> bool:
        _require_win()
        if not self.hwnd:
            return False
        user32.keybd_event(0x12, 0, 0, 0)          # ALT tap: foreground lock
        ok = user32.SetForegroundWindow(self.hwnd)
        user32.keybd_event(0x12, 0, KEYEVENTF_KEYUP, 0)
        return bool(ok)

    def windows(self) -> list[dict]:
        """All visible windows of OUR browser process (popups included)."""
        _require_win()
        if not self.proc:
            return []
        out = []
        for hwnd in _enum_windows():
            if not user32.IsWindowVisible(hwnd):
                continue
            if _win_pid(hwnd) != self.proc.pid:
                continue
            l, t, r, b = _rect_of(hwnd)
            out.append({"handle": hwnd, "title": _win_title(hwnd),
                        "x": l, "y": t, "w": r - l, "h": b - t})
        return out

    def target(self, title_substr: str) -> bool:
        """Switch the driven window (legacy popups!). Bounds/nav/capture all
        follow the new target."""
        _require_win()
        for win in self.windows():
            if title_substr.lower() in win["title"].lower():
                self.hwnd = win["handle"]
                self.x, self.y = win["x"], win["y"]
                self.w, self.h = win["w"], win["h"]
                self.ensure_focus()
                return True
        return False

    # ── observation ─────────────────────────────────────────────────────────
    def screenshot(self, path) -> Path:
        """Hwnd-based capture (PrintWindow) — occlusion-safe; screen-grab
        fallback for exotic windows."""
        _require_win()
        if self.hwnd:
            try:
                return self._capture_hwnd(self.hwnd, path)
            except Exception:  # noqa: BLE001 — fall back to region grab
                pass
        from PIL import ImageGrab
        ImageGrab.grab(bbox=(self.x, self.y, self.x + self.w,
                             self.y + self.h)).save(str(path))
        return Path(path)

    def _capture_hwnd(self, hwnd: int, path) -> Path:
        l, t, r, b = _rect_of(hwnd)
        wd, ht = max(1, r - l), max(1, b - t)
        hdc_win = user32.GetWindowDC(hwnd)
        hdc_mem = gdi32.CreateCompatibleDC(hdc_win)
        hbm = gdi32.CreateCompatibleBitmap(hdc_win, wd, ht)
        gdi32.SelectObject(hdc_mem, hbm)
        try:
            if not user32.PrintWindow(hwnd, hdc_mem, PW_RENDERFULLCONTENT):
                raise DriverError("PrintWindow failed")
            bi = BITMAPINFO()
            bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bi.bmiHeader.biWidth = wd
            bi.bmiHeader.biHeight = -ht        # top-down rows
            bi.bmiHeader.biPlanes = 1
            bi.bmiHeader.biBitCount = 32
            bi.bmiHeader.biCompression = BI_RGB
            buf = ctypes.create_string_buffer(wd * ht * 4)
            if not gdi32.GetDIBits(hdc_mem, hbm, 0, ht, buf,
                                   ctypes.byref(bi), DIB_RGB_COLORS):
                raise DriverError("GetDIBits failed")
            from PIL import Image
            Image.frombytes("RGB", (wd, ht), buf.raw, "raw",
                            "BGRX", 0, 1).save(str(path))
            return Path(path)
        finally:
            gdi32.DeleteObject(hbm)
            gdi32.DeleteDC(hdc_mem)
            user32.ReleaseDC(hwnd, hdc_win)

    def window_bounds(self) -> tuple[int, int, int, int]:
        return (self.x, self.y, self.w, self.h)

    def chrome_title(self) -> str:
        if self.hwnd:
            return _win_title(self.hwnd)
        return ""

    def nav(self, url: str) -> None:
        # Ctrl+L focuses the address bar in IE, Edge and Chrome alike
        self.ensure_focus()
        self.key("ctrl+l")
        time.sleep(0.4)
        self.paste(url)
        time.sleep(0.2)
        self.key("Return")

    # ── Stage 0 / teardown ──────────────────────────────────────────────────
    def _my_window(self) -> int | None:
        if not self.proc:
            return None
        deadline = time.monotonic() + WINDOW_WAIT_S
        while time.monotonic() < deadline:
            wins = self.windows()
            if wins:
                return wins[0]["handle"]
            time.sleep(0.5)
        return None

    def stage0(self) -> dict:
        _require_win()
        kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_DISPLAY_REQUIRED)
        if self.browser == "ie":
            subprocess.run(["taskkill", "/f", "/im", "iexplore.exe"],
                           capture_output=True)
            time.sleep(0.6)
        else:
            self.profile_dir = Path(tempfile.mkdtemp(prefix="hat-profile-"))
        self.proc = subprocess.Popen(self._launch_args("about:blank"))
        hwnd = self._my_window()
        if not hwnd:
            raise DriverError("Stage 0 FAILED: no window appeared for the "
                              "dedicated browser process "
                              f"({self.browser}, ie_mode={self.ie_mode})")
        self.hwnd = hwnd
        user32.SetWindowPos(hwnd, 0, self.x, self.y, self.w, self.h, 0x0040)
        self.ensure_focus()
        self._minimize_all_except(hwnd)
        time.sleep(1.0)
        l, t, r, b = _rect_of(hwnd)
        return {"proof": f"dedicated {self.browser} pid {self.proc.pid} "
                         f"window {r - l}x{b - t} at ({l},{t}), "
                         f"ie_mode={self.ie_mode}, others minimised"}

    def stop(self) -> None:
        """Teardown (POC lesson): kill the process tree, remove the temp
        profile, release the keep-awake lock. Safe to call twice."""
        if IS_WIN and self.proc:
            subprocess.run(["taskkill", "/PID", str(self.proc.pid),
                            "/T", "/F"], capture_output=True)
            self.proc = None
            if self.profile_dir:
                for _ in range(3):               # files unlock asynchronously
                    try:
                        shutil.rmtree(self.profile_dir, ignore_errors=True)
                        if not self.profile_dir.exists():
                            break
                    except OSError:
                        pass
                    time.sleep(0.5)
                self.profile_dir = None
            kernel32.SetThreadExecutionState(ES_CONTINUOUS)
        self.hwnd = None

    def _minimize_all_except(self, keep: int) -> int:
        n = 0
        for hwnd in _enum_windows():
            if hwnd == keep or not user32.IsWindowVisible(hwnd):
                continue
            if user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW:
                continue
            if _win_title(hwnd):
                user32.ShowWindow(hwnd, SW_MINIMIZE)
                n += 1
        return n
