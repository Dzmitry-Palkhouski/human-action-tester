"""App annotation loader — deterministic 1 page = 1 file mapping.

See app-annotation/README.md for the mapping rules. Every annotation file
starts with a `URL: <canonical url>` line — the scenario files never contain
URLs; they reference pages by name and resolve them through annotations.
"""
from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse, parse_qs

DYNAMIC_SEGMENT = re.compile(r"^(\d+|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-.*|[^/]{32,})$")


def page_annotation_path(url: str) -> str:
    """Deterministic annotation file path for a URL (relative to app dir).

    https://app.vidukate.ai/login            -> login.md
    https://app.vidukate.ai/                 -> _root.md
    https://app.vidukate.ai/a/b              -> a__b.md
    https://app.vidukate.ai/sessions/<uuid>  -> sessions__*.md
    .../contentview?studentId=<uuid>         -> contentview__*.md
    .../contentview?studentId=<uuid>&tab=upload -> contentview__*__upload.md
    """
    u = urlparse(url)
    host = u.netloc.split(":")[0]
    segments = []
    for seg in u.path.strip("/").split("/"):
        seg = seg.strip()
        if not seg:
            continue
        segments.append("*" if DYNAMIC_SEGMENT.match(seg) else seg)
    params = parse_qs(u.query)
    tab = params.get("tab", [None])[0]
    # any non-tab query parameter (ids, filters with dynamic values) marks the
    # page as a per-record instance -> one annotation covers them all
    if any(k != "tab" for k in params):
        segments.append("*")
    if tab:
        segments.append(tab)
    if not segments:
        return f"{host}/_root.md"
    return f"{host}/{'__'.join(segments)}.md"


def load_page_annotation(app_dir: Path, url: str) -> str:
    """Return the annotation text for a URL, or '' when none exists."""
    p = Path(app_dir) / page_annotation_path(url)
    if p.exists():
        return p.read_text(encoding="utf-8")
    # dynamic-segment pages fall back to their collapsed template, e.g.
    # sessions__abc.md -> sessions__*.md
    fallback = re.sub(r"__[A-Za-z0-9._-]+\.md$", "__*.md", page_annotation_path(url))
    pf = Path(app_dir) / fallback
    if pf.exists():
        return pf.read_text(encoding="utf-8")
    return ""


def annotation_url(app_dir: Path, url_or_page: str, host: str = "app.vidukate.ai") -> str:
    """Canonical URL for a page: accepts a URL (resolved via its annotation's
    URL line) or a bare page name (e.g. 'dashboard' -> <host>/dashboard.md)."""
    app_dir = Path(app_dir)
    if "://" in url_or_page:
        p = app_dir / page_annotation_path(url_or_page)
    else:
        p = app_dir / host / f"{url_or_page}.md"
    if p.exists():
        m = re.search(r"^URL:\s*(\S+)", p.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1)
    return ""


def annotation_prompt_block(app_dir: Path, url: str) -> str:
    text = load_page_annotation(app_dir, url)
    if not text:
        return ""
    return f"--- PAGE ANNOTATION for {url} (ground truth about this page) ---\n{text}\n"
