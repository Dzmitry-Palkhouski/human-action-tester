"""Perceivers: the "eyes" of the runner.

The runner never needs the host to see images — it asks a Perceiver pointed
questions about a screenshot and gets TEXT back. Two implementations:

- HostFilePerceiver: request/answer files in the run dir. The host (ZCode
  chat wrapper, Copilot CLI agent, or a human) looks at the image and writes
  the answer. Zero API keys, works everywhere.
- HttpVisionPerceiver: direct call to a vision endpoint (OpenAI-compatible
  or Anthropic). For autonomous runs (Copilot CLI / CI), where no human/chat
  host is watching.

Hard limit note: perceiving SCREENSHOTS is the sanctioned way to read the
page. No accessibility trees, no DOM, no CDP — ever.
"""
from __future__ import annotations

import base64
import json
import re
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlparse


class PerceiverError(RuntimeError):
    pass


class HostFilePerceiver:
    """Ask via files: <run>/perceive/req-<id>.json -> ans-<id>.json.

    The chat wrapper services these with `hat perceive --run <dir> pending`
    and `hat perceive --run <dir> answer <id> --text "..."`."""

    def __init__(self, run_dir: Path, timeout_s: float = 300.0):
        self.dir = Path(run_dir) / "perceive"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.timeout_s = timeout_s
        self._seq_file = self.dir / "seq"
        if not self._seq_file.exists():
            self._seq_file.write_text("0")

    def _next_id(self) -> int:
        n = int(self._seq_file.read_text().strip() or "0") + 1
        self._seq_file.write_text(str(n))
        return n

    def ask(self, image: Path, question: str) -> str:
        rid = self._next_id()
        req = self.dir / f"req-{rid}.json"
        ans = self.dir / f"ans-{rid}.json"
        req.write_text(json.dumps({
            "id": rid, "image": str(image), "question": question,
        }, indent=2), encoding="utf-8")
        deadline = time.time() + self.timeout_s
        while time.time() < deadline:
            if ans.exists():
                text = json.loads(ans.read_text(encoding="utf-8")).get("text", "")
                # keep answered requests for the record
                return text
            time.sleep(0.5)
        raise PerceiverError(
            f"perception request {rid} not answered within {self.timeout_s}s "
            f"(host wrapper not servicing {self.dir})")


class HttpVisionPerceiver:
    """Direct vision-API call. OpenAI-compatible (incl. Z.ai GLM) or Anthropic.

    Config: provider, model, endpoint, api key from env var (never in files).
    """

    PROVIDERS = {
        "openai": {"endpoint": "https://api.openai.com/v1/chat/completions",
                   "key_env": "OPENAI_API_KEY", "flavor": "openai"},
        "zai": {"endpoint": "https://api.z.ai/api/paas/v4/chat/completions",
                "key_env": "ZAI_API_KEY", "flavor": "openai"},
        "anthropic": {"endpoint": "https://api.anthropic.com/v1/messages",
                      "key_env": "ANTHROPIC_API_KEY", "flavor": "anthropic"},
    }

    def __init__(self, provider: str = "openai", model: str = "gpt-4o-mini",
                 endpoint: str | None = None, key_env: str | None = None,
                 timeout_s: float = 120.0):
        if provider not in self.PROVIDERS:
            raise PerceiverError(f"unknown provider {provider!r}; "
                                 f"known: {sorted(self.PROVIDERS)}")
        cfg = self.PROVIDERS[provider]
        self.endpoint = endpoint or cfg["endpoint"]
        self.key_env = key_env or cfg["key_env"]
        self.flavor = cfg["flavor"]
        self.model = model
        self.timeout_s = timeout_s

    def ask(self, image: Path, question: str) -> str:
        import os
        key = os.environ.get(self.key_env, "")
        if not key:
            raise PerceiverError(
                f"{self.key_env} is not set — the HTTP perceiver needs it. "
                f"Export the key or use --perceiver host.")
        b64 = base64.b64encode(Path(image).read_bytes()).decode()
        media = "image/png"
        if self.flavor == "anthropic":
            body = {
                "model": self.model, "max_tokens": 1024,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "image",
                         "source": {"type": "base64", "media_type": media,
                                    "data": b64}},
                        {"type": "text", "text": question},
                    ],
                }],
            }
            headers = {"x-api-key": key,
                       "anthropic-version": "2023-06-01",
                       "content-type": "application/json"}
        else:
            body = {
                "model": self.model,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url":
                            {"url": f"data:{media};base64,{b64}"}},
                        {"type": "text", "text": question},
                    ],
                }],
            }
            headers = {"Authorization": f"Bearer {key}",
                       "content-type": "application/json"}
        req = urllib.request.Request(
            self.endpoint, data=json.dumps(body).encode("utf-8"),
            headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_s) as r:
                payload = json.loads(r.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001 — surface a clear message
            raise PerceiverError(f"vision API call failed: {e}") from e
        if self.flavor == "anthropic":
            parts = payload.get("content", [])
            return "".join(p.get("text", "") for p in parts
                           if p.get("type") == "text").strip()
        return payload["choices"][0]["message"]["content"].strip()



class CopilotCliPerceiver:
    """The perceiver IS GitHub Copilot CLI (Sonnet 5.5 with vision).

    No separate vision API component: for each question the runner shells
    out to the authenticated `copilot` CLI (headless, `-p`) with the
    screenshot attached BY PATH — the reliable image route in the CLI
    (clipboard paste is not). Requires the user's Copilot subscription and
    a model with image input selected (e.g. claude-sonnet-5.5).

    Binary/flags are env-overridable because CLI versions differ:
      HAT_COPILOT_BIN      (default "copilot")
      HAT_COPILOT_IMAGE    (default "--image"; set "" if your version
                            attaches image paths written in the prompt)
      HAT_COPILOT_EXTRA    (default ""; extra args, e.g. "--allow-all-tools")
    """

    def __init__(self, model: str | None = None, timeout_s: float = 240.0):
        import os
        import shutil
        self.bin = os.environ.get("HAT_COPILOT_BIN", "copilot")
        if not shutil.which(self.bin):
            raise PerceiverError(
                f"{self.bin!r} not found on PATH — install GitHub Copilot CLI "
                f"and sign in, or set HAT_COPILOT_BIN.")
        self.image_flag = os.environ.get("HAT_COPILOT_IMAGE", "--image")
        self.extra = os.environ.get("HAT_COPILOT_EXTRA", "").split()
        self.model = model
        self.timeout_s = timeout_s

    def ask(self, image: Path, question: str) -> str:
        import subprocess
        prompt = (f"{question}\n"
                  f"(Answer with ONLY the requested format, nothing else.)")
        cmd = [self.bin]
        if self.model:
            cmd += ["--model", self.model]
        if self.image_flag:
            cmd += [self.image_flag, str(image)]
        cmd += self.extra + ["-p", prompt]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=self.timeout_s)
        except subprocess.TimeoutExpired as e:
            raise PerceiverError(f"copilot CLI timed out after "
                                 f"{self.timeout_s}s") from e
        if r.returncode != 0:
            raise PerceiverError(f"copilot CLI failed ({r.returncode}): "
                                 f"{r.stderr.strip()[:400]}")
        answer = r.stdout.strip()
        if not answer:
            raise PerceiverError("copilot CLI returned empty output")
        return answer


PERCENT_RE = re.compile(r"x\s*=\s*([\d.]+)\s*%\D*y\s*=\s*([\d.]+)\s*%",
                        re.IGNORECASE)


def parse_percent_point(answer: str):
    """Extract 'x=31.5%, y=5.9%' from a perceiver answer -> (fx, fy) floats."""
    m = PERCENT_RE.search(answer)
    if not m:
        return None
    return float(m.group(1)) / 100.0, float(m.group(2)) / 100.0
