"""macOS PlatformDriver: real input events only.

Wraps bin/had (CGEvent) — posted through the persistent Terminal daemon when
alive (no focus churn), else through the self-closing term.sh runner. Window
management via WindowController (OS-level AX window attributes only — never
page content; see the HARD LIMIT in docs/04).
"""
from __future__ import annotations

import subprocess
import time
from pathlib import Path

from .driver import BROWSERS, TerminalRunner
from .window import WindowController, WindowHandle

ROOT = Path(__file__).resolve().parents[2]
HAD = ROOT / "bin" / "had"
TERM = ROOT / "poc" / "term.sh"
FIFO = Path("/tmp/had_cmds.fifo")


class MacDriver:
    """The driver protocol on macOS (chrome incognito test window at 0,33)."""

    def __init__(self, browser: str = "chrome", bounds: tuple = (0, 33, 1470, 825)):
        if browser not in BROWSERS:
            raise ValueError(f"unknown browser {browser!r}")
        self.browser = browser
        self.ctl = WindowController()
        self.runner = TerminalRunner()
        self.handle = WindowHandle(x=bounds[0], y=bounds[1],
                                   w=bounds[2], h=bounds[3])

    # -- input ---------------------------------------------------------------
    def _had(self, *args) -> None:
        argline = " ".join(str(a) for a in args)
        # prefer the persistent daemon: no Terminal activation, no focus steal
        if FIFO.exists():
            try:
                with open(FIFO, "w") as f:
                    f.write(argline + "\n")
                time.sleep(0.12)
                return
            except OSError:
                pass
        subprocess.run(["bash", str(TERM), str(HAD) + " " + argline],
                       capture_output=True, text=True)

    def click(self, x, y): self._had("click", x, y)
    def tripleclick(self, x, y): self._had("tripleclick", x, y)
    def key(self, chord): self._had("key", chord)
    def type(self, text: str):
        # paste instead of type: CGEvent unicode typing drops characters in
        # Chromium (measured 7-of-10) — clipboard is deterministic and is a
        # real user action
        self.paste(text)

    def paste(self, text: str):
        """Clipboard paste via System Events (input event, not page access)."""
        safe = text.replace("'", "'\\''")
        script = (f"printf %s '{safe}' | pbcopy; "
                  f"osascript -e 'tell application \"System Events\" to "
                  f"keystroke \"v\" using command down'")
        self.runner.run(script)
        time.sleep(0.25)

    # -- observation / window ------------------------------------------------
    def screenshot(self, path) -> Path:
        x, y, w, h = self.window_bounds()
        subprocess.run(["screencapture", "-x", "-R",
                        f"{x},{y},{w},{h}", str(path)], capture_output=True)
        return Path(path)

    def window_bounds(self) -> tuple[int, int, int, int]:
        return (self.handle.x, self.handle.y, self.handle.w, self.handle.h)

    def nav(self, url: str) -> None:
        self.ctl.refocus(self.handle)
        self._had("tripleclick", 500, 56)
        time.sleep(0.4)
        self.paste(url)
        time.sleep(0.3)
        self._had("key", "Return")

    def stage0(self) -> dict:
        self.ctl.minimize_everything_else(self.handle)
        proof = self.ctl.create(self.handle)      # +1 proof or raises
        self._had("sleep", "200")                 # let the window settle
        return proof

    def refocus(self) -> bool:
        return self.ctl.refocus(self.handle)

    def ensure_focus(self) -> None:
        """Per-action focus gate (POC lesson): never send input blind."""
        import time as _t
        for _ in range(3):
            if self.ctl.refocus(self.handle):
                return
            _t.sleep(0.4)
        raise RuntimeError("target window could not be focused — input suppressed")

    def windows(self) -> list[dict]:
        """Visible Chrome windows (popups included) via System Events."""
        script = '''
        tell application "System Events" to tell process "Google Chrome"
            set out to ""
            repeat with w in windows
                try
                    if (value of attribute "AXMinimized" of w) is false then
                        set p to position of w
                        set s to size of w
                        set out to out & (value of attribute "AXTitle" of w) & "\t" & (item 1 of p) & "," & (item 2 of p) & "," & (item 1 of s) & "," & (item 2 of s) & linefeed
                    end if
                end try
            end repeat
            return out
        end tell'''
        out = []
        for line in self.runner.run("osascript -e " + repr(script).replace("'", '"')).splitlines():
            if "\t" not in line:
                continue
            title, geom = line.rsplit("\t", 1)
            try:
                x, y, w, h = (int(v) for v in geom.split(","))
                out.append({"handle": title, "title": title,
                            "x": x, "y": y, "w": w, "h": h})
            except ValueError:
                continue
        return out

    def target(self, title_substr: str) -> bool:
        """Switch the driven window (popups): match by title substring, raise
        it, adopt its geometry so bounds/screenshot follow the new target."""
        for win in self.windows():
            if title_substr.lower() in win["title"].lower():
                self.handle.x, self.handle.y = win["x"], win["y"]
                self.handle.w, self.handle.h = win["w"], win["h"]
                self.handle.title_marker = win["title"]
                self.ctl.refocus(self.handle)
                return True
        return False

    def stop(self) -> None:
        """Teardown: close our window (matched by adopted title), minimise
        guard state is per-run anyway. Safe to call twice."""
        marker = self.handle.title_marker
        script = '''
        tell application "Google Chrome"
            repeat with w in windows
                try
                    if (name of w) contains "MARKER" then
                        close w
                    end if
                end try
            end repeat
        end tell'''.replace("MARKER", marker.replace('"', ''))
        try:
            self.runner.run("osascript -e " + repr(script).replace("'", '"'))
        except Exception:  # noqa: BLE001 - teardown is best-effort
            pass
