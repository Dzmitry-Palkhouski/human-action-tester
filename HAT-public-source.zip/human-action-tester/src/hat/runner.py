"""The CLI run engine — one command takes a flow end to end.

Both hosts converge here:
- ZCode chat wrapper: `hat run ... --perceiver host`, the chat services the
  perception request files (the SAME CLI implementation, host only answers).
- GitHub Copilot CLI: `hat run ... --perceiver http` (autonomous) or the
  agent itself services host requests like any other host.

Steps carry an optional machine plan (the `Plan:` bullet, commands separated
by `;`, or a sidecar JSON plan file). The engine executes primitives through
a PlatformDriver; coordinates are located at runtime by asking the perceiver
for percentages of the CURRENT screenshot — never hardcoded. Every step is
bounded by the attempts budget (default 3): unreached state after N attempts
records FAIL and moves on. Endless retry is structurally impossible.

HARD LIMIT: driver primitives are real user input only (clicks, typing,
chords). No accessibility trees, no DOM, no CDP — ever.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path

from . import data as data_mod
from .flow import Flow, Step, load_flow
from .perceiver import PerceiverError, parse_percent_point
from .driver import PlatformDriver
from .session import Session, StepRecord

VERDICT_RE = re.compile(r"VERDICT:\s*(PASS|FAIL|INCONCLUSIVE)",
                        re.IGNORECASE)


class DriverError(RuntimeError):
    pass


class RunEngine:
    def __init__(self, flow: Flow, driver: PlatformDriver, perceiver, run_dir: Path,
                 row: dict | None = None,
                 dictionary: data_mod.DataDictionary | None = None,
                 max_attempts: int = 3,
                 plan_file: Path | None = None,
                 settle_s: float = 2.0,
                 keep_browser: bool = False):
        self.flow = flow
        self.driver = driver
        self.perceiver = perceiver
        self.run_dir = Path(run_dir)
        self.shots = self.run_dir / "screenshots"
        self.shots.mkdir(parents=True, exist_ok=True)
        self.row = row or {}
        self.dictionary = dictionary
        self.max_attempts = max_attempts or flow.max_attempts
        self.plans = {}
        if plan_file and Path(plan_file).exists():
            import json
            self.plans = {int(k): v for k, v in
                          json.loads(Path(plan_file).read_text()).items()}
        self.settle_s = settle_s
        self.keep_browser = keep_browser
        self._tried: dict[str, tuple[float, float]] = {}  # desc -> last tried %
        self.session = Session(test_case=self._test_case())

    # -- helpers -------------------------------------------------------------
    def _test_case(self) -> dict:
        meta = self.flow.meta
        row = self.row
        return {
            "id": meta.get("id", "UNKNOWN"),
            "title": meta.get("title", ""),
            "target": meta.get("target", ""),
            "browser": meta.get("browser", "chrome"),
            "machine": meta.get("machine", ""),
            "executed_by": ("Human Action Driver via `hat run` "
                            "(CLI runner; real input events + screenshot "
                            "vision; no Selenium/Playwright/CDP/AX)"),
            "data_row": (f"row {row.get('row_id', '?')} "
                         f"(purpose={row.get('purpose', '?')})") if row else "-",
            "date": time.strftime("%Y-%m-%d"),
            "started": time.strftime("%H:%M"),
            "finished": "",
            "mode": "cli-runner",
        }

    def _raw(self, text: str) -> str:
        """Resolve placeholders WITHOUT masking — engine needs real values.
        Values live in process memory only and never reach artifacts."""
        return data_mod.resolve(text, self.flow.meta, self.row)

    def _shot(self, name: str) -> Path:
        p = self.shots / name
        self.driver.screenshot(p)
        return p

    def _locate(self, description: str, shot: Path):
        """Ask the perceiver where something is; return point coords or None."""
        hint = ""
        if description in self._tried:
            tfx, tfy = self._tried[description]
            hint = (f" NOTE: a previous attempt already clicked x={tfx*100:.1f}%, "
                    f"y={tfy*100:.1f}% for '{description}' and it did NOT "
                    f"activate anything - the visible text may not be the "
                    f"clickable part. Find the actual clickable affordance "
                    f"(icon, button, image) for it, and give ITS center.")
        ans = self.perceiver.ask(
            shot,
            f"Look at this browser screenshot. Give the CENTER of the "
            f"'{description}' as exact percentages of the image, in the form "
            f"x=NN.N%, y=NN.N%. If it is not visible, answer NOT_VISIBLE."
            f"{hint}")
        if "NOT_VISIBLE" in ans.upper():
            return None
        pt = parse_percent_point(ans)
        if pt is None:
            return None
        fx, fy = pt
        x, y, w, h = self.driver.window_bounds()
        return (int(x + fx * w), int(y + fy * h)), (fx, fy)

    def _step_plan(self, step: Step) -> list[str]:
        if step.n in self.plans:
            return [self._raw(str(c)) for c in self.plans[step.n]]
        plan = step.fields.get("plan", "")
        return [self._raw(c.strip()) for c in plan.split(";") if c.strip()]

    # -- primitives ----------------------------------------------------------
    def _exec_line(self, line: str, step_no: int, seq: list) -> str | None:
        """Execute one plan primitive. Returns 'fail' on failure, else None."""
        parts = line.split(None, 1)
        cmd, rest = parts[0].lower(), (parts[1].strip() if len(parts) > 1 else "")
        INPUT_CMDS = ("nav", "click", "tripleclick", "type", "paste", "key",
                      "dismiss", "window")
        if cmd in INPUT_CMDS:
            try:
                self.driver.ensure_focus()
            except Exception as e:  # noqa: BLE001 — gate failure = attempt miss
                return f"focus gate failed: {e}"
        if cmd == "nav":
            self.driver.nav(self._raw(rest))
        elif cmd == "click":
            shot = self._shot(f"s{step_no}_locate_{len(seq)}.png")
            loc = self._locate(rest, shot)
            if loc is None:
                return f"could not locate '{rest}'"
            pt, pct = loc
            self._tried[rest] = pct
            self.driver.click(*pt)
        elif cmd == "dismiss":
            # resilience primitive: vision-locate an obstructing element and
            # click it; absent (NOT_VISIBLE) is fine - nothing to dismiss
            shot = self._shot(f"s{step_no}_dismiss_{len(seq)}.png")
            loc = self._locate(rest, shot)
            if loc is not None:
                pt, pct = loc
                self._tried[rest] = pct
                self.driver.click(*pt)
        elif cmd == "window":
            # popup support (POC lesson): switch the driven window by title
            if not self.driver.target(rest):
                return (f"no window of the controlled browser has a title "
                        f"containing '{rest}'")
        elif cmd == "type":
            self.driver.type(rest)
        elif cmd == "paste":
            self.driver.paste(rest)
        elif cmd == "key":
            self.driver.key(rest)
        elif cmd == "tripleclick":
            shot = self._shot(f"s{step_no}_locate_{len(seq)}.png")
            pt = self._locate(rest, shot)
            if pt is None:
                return f"could not locate '{rest}'"
            self.driver.tripleclick(*pt)
        elif cmd == "wait":
            time.sleep(float(rest or "1"))
        elif cmd == "shot":
            self._shot(f"s{step_no}_{len(seq)}.png")
        elif cmd == "verify":
            shot = self._shot(f"s{step_no}_verify.png")
            ans = self.perceiver.ask(
                shot,
                f"You are judging a UI test step. Question: {rest}\n"
                f"Look at the screenshot and answer with exactly one line: "
                f"VERDICT: PASS or FAIL or INCONCLUSIVE — <one sentence of "
                f"what you see>.")
            m = VERDICT_RE.search(ans)
            self.last_verify = (m.group(1).upper() if m else "INCONCLUSIVE"), ans
            return None
        else:
            return f"unknown primitive '{cmd}'"
        return None

    # -- engine --------------------------------------------------------------
    def run(self) -> Session:
        try:
            self.driver.stage0()
            self._shot("s0_stage.png")
            for step in self.flow.steps:
                rec = self._run_step(step)
                self.session.steps.append(rec)
                self.session.save(self.run_dir / f"{self.flow.id}.session.json")
            self.session.test_case["finished"] = time.strftime("%H:%M")
            return self.session
        finally:
            # teardown (POC lesson): kill the browser tree + temp profile -
            # a run must not leak processes; keep_browser is for debugging
            if not self.keep_browser:
                try:
                    self.driver.stop()
                except Exception:  # noqa: BLE001 - teardown must not mask errors
                    pass

    def _run_step(self, step: Step) -> StepRecord:
        resolved = data_mod.resolve_step(step.fields, self.flow.meta,
                                         self.row, self.dictionary)
        rec = StepRecord(n=step.n, title=step.title,
                         description=resolved.get("description", ""),
                         action=resolved.get("action", ""),
                         input=resolved.get("input", ""),
                         expected=resolved.get("expected", ""))
        plan = self._step_plan(step)
        self.last_verify = None
        self._tried = {}          # per-step; carried ACROSS attempts (hints)
        attempts = 0
        while attempts < self.max_attempts:
            attempts += 1
            seq = []
            failure = None
            for line in plan:
                seq.append(line)
                failure = self._exec_line(line, step.n, seq)
                if failure:
                    break
            if failure is None and self.last_verify is not None:
                verdict, ans = self.last_verify
                rec.actual = ans.split("—", 1)[-1].strip() or ans
                rec.verdict = verdict
                rec.attempts = attempts
                rec.screenshot = f"s{step.n}_verify.png"
                if verdict != "FAIL":
                    return rec
                failure = f"verify failed on attempt {attempts}"
            # any non-reached state (locate miss or verify FAIL) retries
            # until the attempts budget is exhausted — then FAIL and move on
            time.sleep(self.settle_s)
        rec.verdict = rec.verdict if rec.verdict != "PENDING" else "FAIL"
        rec.attempts = attempts
        rec.actual = (rec.actual or "") + \
            f" [not reached after {attempts} attempt(s); last failure: {failure}]"
        if not rec.screenshot:
            rec.screenshot = f"s{step.n}_verify.png"
        return rec
