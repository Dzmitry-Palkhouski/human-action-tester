"""Human Action Driver backends.

`LocalMacDriver` performs real human-level I/O on macOS:
  - keyboard / mouse  -> bin/had (compiled Swift CGEvent tool)
  - running `had`     -> through Terminal (osascript `do script`), because
                         macOS TCC grants Accessibility per responsible
                         process and Terminal holds the grant; its children
                         inherit it. Capture/queries run in-process.
  - screenshots       -> /usr/sbin/screencapture (Screen Recording)
  - app orchestration -> AppleScript (Automation): activate, window bounds,
                         Chrome tab URL. Never used to touch page content.

`DryRunDriver` records intents and executes nothing (tests, `hat plan`).
"""
from __future__ import annotations

import subprocess
import time
from pathlib import Path

HAD_DEFAULT = Path(__file__).resolve().parents[2] / "bin" / "had"

# Stage 0 helper: minimise every window of every visible app EXCEPT the
# front window of the target browser (that is our fresh test window).
# Idempotent — re-run before any interaction to re-assert the clean stage
# (physical clicks and app activations can re-raise other windows).
# Run through the Terminal runner (System Events needs Terminal's AX grant).
MINIMIZE_ALL_APPLESCRIPT = '''tell application "System Events"
	set n to 0
	set browserProc to "Google Chrome"
	repeat with p in (application processes whose visible is true and background only is false)
		try
			set pname to name of p
			repeat with w in windows of p
				try
					if pname is browserProc and w is (window 1 of p) then
						-- keep our front test window
					else
						set value of attribute "AXMinimized" of w to true
						set n to n + 1
					end if
				end try
			end repeat
		end try
	end repeat
	return n as string
end tell'''

# Browsers the stage setup knows how to drive. Chromium-family browsers share
# one AppleScript dictionary; Safari needs its own (weaker) adapter.
BROWSERS = {
    "chrome": {"app": "Google Chrome", "kind": "chromium"},
    "edge": {"app": "Microsoft Edge", "kind": "chromium"},
    "brave": {"app": "Brave", "kind": "chromium"},
    "safari": {"app": "Safari", "kind": "webkit"},
}


class TerminalRunner:
    """Runs shell commands inside Terminal (the Accessibility grant holder)."""

    def __init__(self, done_marker: Path = Path("/tmp/had_term.done"),
                 out_file: Path = Path("/tmp/had_term.out"),
                 timeout: float = 60.0):
        self.done_marker = done_marker
        self.out_file = out_file
        self.timeout = timeout

    def run(self, command: str, blocking: bool = True) -> str:
        self.done_marker.unlink(missing_ok=True)
        self.out_file.unlink(missing_ok=True)
        wrapped = (f"{command} > {self.out_file} 2>&1; "
                   f"echo __RC__=$? > {self.done_marker}")
        script = f'tell application "Terminal" to do script {self._as(wrapped)}'
        subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
        if not blocking:
            return ""
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            if self.done_marker.exists():
                time.sleep(0.1)
                return self.out_file.read_text() if self.out_file.exists() else ""
            time.sleep(0.2)
        raise TimeoutError(f"Terminal runner timed out: {command!r}")

    @staticmethod
    def _as(text: str) -> str:
        return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'



# ── PlatformDriver: the ONE interface a platform must implement ──────────────
# The runner (hat run) drives a browser exclusively through these methods.
# macOS: MacDriver (driver_mac.py, CGEvent via bin/had). Windows port:
# in-process SendInput implementing the same protocol. HARD LIMIT: these are
# real user input events and screenshot observation only — never
# accessibility-tree/DOM/CDP access to page content.
from typing import Protocol, runtime_checkable


@runtime_checkable
class PlatformDriver(Protocol):
    def stage0(self) -> dict: ...
    def nav(self, url: str) -> None: ...
    def click(self, x: int, y: int) -> None: ...
    def tripleclick(self, x: int, y: int) -> None: ...
    def type(self, text: str) -> None: ...
    def paste(self, text: str) -> None: ...
    def key(self, chord: str) -> None: ...
    def screenshot(self, path) -> object: ...
    def window_bounds(self) -> tuple: ...
    def refocus(self) -> bool: ...
    def ensure_focus(self) -> None: ...
    def windows(self) -> list: ...
    def target(self, title_substr: str) -> bool: ...
    def stop(self) -> None: ...


class BaseDriver:
    def click(self, x: int, y: int): raise NotImplementedError
    def doubleclick(self, x: int, y: int): raise NotImplementedError
    def tripleclick(self, x: int, y: int): raise NotImplementedError
    def move(self, x: int, y: int): raise NotImplementedError
    def drag(self, x1: int, y1: int, x2: int, y2: int): raise NotImplementedError
    def scroll(self, dx: int, dy: int): raise NotImplementedError
    def key(self, chord: str): raise NotImplementedError
    def type(self, text: str): raise NotImplementedError
    def sleep_ms(self, ms: int): raise NotImplementedError
    def activate(self, app: str): raise NotImplementedError
    def screenshot(self, path: str, region: str | None = None) -> Path:
        raise NotImplementedError
    def chrome_front_url(self) -> str | None: raise NotImplementedError
    def prepare_stage(self, browser: str = "chrome",
                      bounds: str = "0, 33, 1470, 858"): raise NotImplementedError


class DryRunDriver(BaseDriver):
    """Records every intent; executes nothing. Also used by `hat plan`."""

    def __init__(self):
        self.intents: list[str] = []

    def _log(self, text: str):
        self.intents.append(text)

    def click(self, x, y): self._log(f"had click {x} {y}")
    def doubleclick(self, x, y): self._log(f"had doubleclick {x} {y}")
    def tripleclick(self, x, y): self._log(f"had tripleclick {x} {y}")
    def move(self, x, y): self._log(f"had move {x} {y}")
    def drag(self, x1, y1, x2, y2): self._log(f"had drag {x1} {y1} {x2} {y2}")
    def scroll(self, dx, dy): self._log(f"had scroll {dx} {dy}")
    def key(self, chord): self._log(f"had key {chord}")
    def type(self, text): self._log(f"had type {text!r}")
    def sleep_ms(self, ms): self._log(f"had sleep {ms}")
    def activate(self, app): self._log(f"osascript activate {app!r}")
    def screenshot(self, path, region=None):
        self._log(f"screencapture -x -R{region or 'fullscreen'} {path}")
        return Path(path)
    def chrome_front_url(self):
        self._log("osascript: get URL of active tab of front window (Chrome)")
        return None
    def prepare_stage(self, browser="chrome", bounds="0, 33, 1470, 858",
                      incognito=True):
        if browser not in BROWSERS:
            raise ValueError(f"unknown browser {browser!r}; known: {sorted(BROWSERS)}")
        info = BROWSERS[browser]
        self._log("prepare_stage: minimise ALL windows of every visible app")
        self._log(f"prepare_stage[{browser}]: activate {info['app']}")
        self._log(f"prepare_stage[{browser}]: new {'incognito ' if incognito else ''}"
                  f"window, bounds {bounds}")
    def stage0(self):
        self.prepare_stage("chrome")
        return {"proof": "dry-run: incognito +1 (not executed)"}
    def nav(self, url): self._log(f"nav {url}")
    def paste(self, text): self._log(f"paste {text!r}")
    def window_bounds(self): return (0, 33, 1470, 825)
    def refocus(self): self._log("refocus remembered window"); return True
    def ensure_focus(self): self._log("ensure_focus (gate)")
    def windows(self): return [{"handle": 1, "title": "Main (Incognito)",
                                "x": 0, "y": 33, "w": 1470, "h": 825}]
    def target(self, t):
        self._log(f"target {t!r}")
        return True
    def stop(self): self._log("stop: teardown browser + profile")


class LocalMacDriver(BaseDriver):
    def __init__(self, had: Path = HAD_DEFAULT, runner: TerminalRunner | None = None):
        self.had = str(had)
        self.runner = runner or TerminalRunner()

    # -- input events (through Terminal for the TCC grant) ------------------
    def _had(self, *args: str):
        return self.runner.run(f"{self.had} {' '.join(args)}")

    def click(self, x, y): self._had("click", str(x), str(y))
    def doubleclick(self, x, y): self._had("doubleclick", str(x), str(y))
    def tripleclick(self, x, y): self._had("tripleclick", str(x), str(y))
    def move(self, x, y): self._had("move", str(x), str(y))
    def drag(self, x1, y1, x2, y2):
        self._had("drag", str(x1), str(y1), str(x2), str(y2))
    def scroll(self, dx, dy): self._had("scroll", str(dx), str(dy))
    def key(self, chord): self._had("key", chord)
    def type(self, text: str):
        # newline at the end means "press Return" (see had type)
        safe = text.replace('"', '\\"')
        self.runner.run(f'{self.had} type "{safe}"')
    def sleep_ms(self, ms): self._had("sleep", str(ms))
    def activate(self, app: str):
        subprocess.run(["open", "-a", app], capture_output=True)

    # -- observation (in-process; Screen Recording + Automation) ------------
    def screenshot(self, path: str, region: str | None = None) -> Path:
        cmd = ["screencapture", "-x"]
        if region:
            cmd += ["-R", region]
        cmd.append(str(path))
        subprocess.run(cmd, capture_output=True)
        return Path(path)

    def chrome_front_url(self) -> str | None:
        script = ('tell application "Google Chrome" to get URL of active tab '
                  'of front window')
        r = subprocess.run(["osascript", "-e", script], capture_output=True,
                           text=True)
        return r.stdout.strip() if r.returncode == 0 else None

    def chrome_window_bounds(self) -> str | None:
        script = 'tell application "Google Chrome" to get bounds of front window'
        r = subprocess.run(["osascript", "-e", script], capture_output=True,
                           text=True)
        return r.stdout.strip() if r.returncode == 0 else None

    def chrome_dedicated_window(self, bounds="0, 33, 1470, 858") -> None:
        """Deprecated alias for prepare_stage('chrome', bounds)."""
        self.prepare_stage("chrome", bounds)

    # -- stage setup (Stage 0): deterministic test surface ------------------
    def prepare_stage(self, browser: str = "chrome",
                      bounds: str = "0, 33, 1470, 858",
                      incognito: bool = True) -> None:
        """Stage 0 — MANDATORY before every session (see docs/04):
        1. activate the browser and create ONE fresh window at fixed bounds
           (incognito for Chromium = clean state, no stored sessions);
        2. minimise EVERY window of every visible app EXCEPT that new window
           (Terminal ctx: AX grant). Idempotent — `assert_stage` re-runs it.
        3. the caller verifies with a full-screen capture that exactly one
           window is visible before sending any input.
        Skipping this is how keystrokes end up in unrelated windows."""
        if browser not in BROWSERS:
            raise ValueError(f"unknown browser {browser!r}; known: {sorted(BROWSERS)}")
        info = BROWSERS[browser]
        # 1) fresh dedicated window (activates the app; becomes front window)
        if info["kind"] == "chromium":
            mode = ' with properties {mode:"incognito"}' if incognito else ""
            script = f'''
            tell application "{info["app"]}"
              activate
              set newWin to make new window{mode}
              set bounds of newWin to {{{bounds}}}
              return id of newWin
            end tell'''
        else:  # webkit / Safari: fresh document + bounds (no incognito concept)
            script = f'''
            tell application "{info["app"]}"
              activate
              make new document
              set bounds of front window to {{{bounds}}}
              return id of front window
            end tell'''
        r = subprocess.run(["osascript", "-e", script],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"stage setup failed for {browser}: "
                               f"{r.stderr.strip()}")
        # 2) minimise everything except the new front window
        self.assert_stage()

    def assert_stage(self, browser: str = "chrome") -> str:
        """Re-minimise all windows except the browser's front window and
        return the minimise count (cheap, idempotent, call before any
        interaction batch)."""
        minimize_file = Path("/tmp/hat_minimize_all.applescript")
        minimize_file.write_text(MINIMIZE_ALL_APPLESCRIPT, encoding="utf-8")
        return self.runner.run(f"osascript {minimize_file}").strip()
