"""Replay driver: compare a replay session against its baseline.

Outcome matrix (baseline → replay):
  FAIL  -> PASS          FIXED
  FAIL  -> FAIL          STILL FAILING
  PASS  -> FAIL          REGRESSION
  PASS  -> PASS          STILL PASSING
  any   -> INCONCLUSIVE  INCONCLUSIVE
  any   -> PENDING       NOT RUN
"""
from __future__ import annotations

from dataclasses import dataclass

from .session import Session

OUTCOMES = {
    ("FAIL", "PASS"): "FIXED",
    ("FAIL", "FAIL"): "STILL FAILING",
    ("PASS", "FAIL"): "REGRESSION",
    ("PASS", "PASS"): "STILL PASSING",
}


@dataclass
class StepCompare:
    n: int
    title: str
    baseline_verdict: str
    replay_verdict: str
    outcome: str


def _outcome(baseline: str, replay: str) -> str:
    if replay == "INCONCLUSIVE" or baseline == "INCONCLUSIVE":
        return "INCONCLUSIVE"
    if replay == "PENDING":
        return "NOT RUN"
    return OUTCOMES.get((baseline, replay), "INCONCLUSIVE")


def compare(baseline: Session, replay: Session) -> list[StepCompare]:
    base = {s.n: s for s in baseline.steps}
    rep = {s.n: s for s in replay.steps}
    out = []
    for n in sorted(set(base) | set(rep)):
        b = base.get(n)
        r = rep.get(n)
        out.append(StepCompare(
            n=n,
            title=(r.title if r else (b.title if b else "")),
            baseline_verdict=b.verdict if b else "-",
            replay_verdict=r.verdict if r else "-",
            outcome=_outcome(b.verdict if b else "-",
                             r.verdict if r else "PENDING"),
        ))
    return out


def summary(compares: list[StepCompare]) -> dict:
    counts: dict = {}
    for c in compares:
        counts[c.outcome] = counts.get(c.outcome, 0) + 1
    return counts


def format_table(compares: list[StepCompare]) -> str:
    header = f"{'Step':<6}{'Baseline':<14}{'Replay':<14}{'Outcome':<16}Title"
    lines = [header, "-" * len(header)]
    for c in compares:
        lines.append(f"{c.n:<6}{c.baseline_verdict:<14}{c.replay_verdict:<14}"
                     f"{c.outcome:<16}{c.title}")
    return "\n".join(lines)
