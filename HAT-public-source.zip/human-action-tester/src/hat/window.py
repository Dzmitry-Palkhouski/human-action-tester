"""Persistent browser-window handle.

A test session creates ONE dedicated browser window and remembers it in a
state file. Every subsequent operation re-focuses THAT window by its unique
descriptor — title marker + exact position/size — never by "whatever Chrome
happens to have front". If the window dies (closed, relaunch, crash), that is
detected loudly instead of keystrokes silently landing elsewhere.

Incognito windows are invisible to Chrome's AppleScript dictionary, so the
handle is identified through the Accessibility tree (System Events), which is
reached through the Terminal runner (Terminal holds the AX grant).
"""
from __future__ import annotations

import json
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .driver import TerminalRunner

DEFAULT_POSITION = (0, 33)
DEFAULT_SIZE = (1470, 825)   # Chrome AppleScript bounds are CORNERS: {0,33,1470,858} == size 1470x825
POSITION_TOLERANCE = 8  # points; AX positions are integers, allow jitter


@dataclass
class WindowHandle:
    app: str = "Google Chrome"
    browser: str = "chrome"
    incognito: bool = True
    title_marker: str = "(Incognito)"
    x: int = DEFAULT_POSITION[0]
    y: int = DEFAULT_POSITION[1]
    w: int = DEFAULT_SIZE[0]
    h: int = DEFAULT_SIZE[1]
    created_at: str = ""

    @property
    def bounds(self) -> tuple[int, int, int, int]:
        """Corners {left, top, right, bottom} for Chrome AppleScript."""
        return (self.x, self.y, self.x + self.w, self.y + self.h)

    def save(self, path: Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        return path

    @classmethod
    def load(cls, path: Path) -> "WindowHandle":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


class WindowController:
    """Creates / re-focuses / checks the remembered window via System Events."""

    def __init__(self, runner: TerminalRunner | None = None):
        self.runner = runner or TerminalRunner()

    # -- low-level appleScript runner ---------------------------------------
    def _osascript(self, script: str) -> str:
        f = Path("/tmp/hat_window.applescript")
        f.write_text(script, encoding="utf-8")
        return self.runner.run(f"osascript {f}").strip()

    # -- creation -------------------------------------------------------------
    def create(self, handle: WindowHandle) -> dict:
        """Create a BRAND-NEW window (never reuse) and prove it: the number of
        incognito windows must increase by exactly one, and that new window
        must end up front. Retries up to 3 times; raises with the window
        inventory if the proof never passes."""
        from datetime import datetime
        handle.created_at = datetime.now().isoformat(timespec="seconds")
        if handle.incognito:
            new_win = 'make new window with properties {mode:"incognito"}'
        else:
            new_win = "make new window"
        inventory = self._osascript(f'''
        tell application "System Events" to tell process "{handle.app}"
            set out to ""
            repeat with w in windows
                try
                    set p to position of w
                    set s to size of w
                    set out to out & (value of attribute "AXTitle" of w) & \\
                        " @" & (item 1 of p) & "," & (item 2 of p) & \\
                        " " & (item 1 of s) & "x" & (item 2 of s) & linefeed
                end try
            end repeat
            return out
        end tell''')
        before = self.count_incognito(handle)

        last_error = ""
        for attempt in range(1, 4):
            create = f'''
            tell application "{handle.app}"
              activate
              set newWin to {new_win}
              delay 0.3
              set bounds of newWin to {{{handle.x}, {handle.y}, {handle.x + handle.w}, {handle.y + handle.h}}}
            end tell'''
            self._osascript(create)
            # proof loop: the new window must appear, be incognito, front, at bounds
            for _ in range(6):
                after = self.count_incognito(handle)
                front_ok = self.refocus(handle, retries=1)
                if after == before + 1 and front_ok:
                    return {"proof": f"incognito windows {before} -> {after} "
                                     f"(+1), new window front", "attempt": attempt}
                time.sleep(0.7)
            last_error = (f"attempt {attempt}: count {before}->{after}, "
                          f"front_ok={front_ok}")
        inv = self._osascript(f'''
        tell application "System Events" to tell process "{handle.app}"
            set out to ""
            repeat with w in windows
                try
                    set out to out & (value of attribute "AXTitle" of w) & linefeed
                end try
            end repeat
            return out
        end tell''')
        raise RuntimeError(
            f"STAGE 0 FAILED after 3 attempts ({last_error}). "
            f"Window inventory:\\n{inventory}\\n{inv}")

    # -- finding / focusing ---------------------------------------------------
    def _find_script(self, handle: WindowHandle, raise_it: bool) -> str:
        tol = POSITION_TOLERANCE
        x, y, w, h = handle.x, handle.y, handle.w, handle.h
        marker = handle.title_marker.replace('"', '\\"')
        raise_line = 'perform action "AXRaise" of found' if raise_it else ""
        cond = (f"(item 1 of p) > {x - tol} and (item 1 of p) < {x + tol} and "
                f"(item 2 of p) > {y - tol} and (item 2 of p) < {y + tol} and "
                f"(item 1 of s) > {w - tol} and (item 1 of s) < {w + tol} and "
                f"(item 2 of s) > {h - tol} and (item 2 of s) < {h + tol}")
        return f'''
        tell application "System Events" to tell process "{handle.app}"
            set found to missing value
            repeat with w in windows
                try
                    set p to position of w
                    set s to size of w
                    if {cond} then
                        if (value of attribute "AXTitle" of w) contains "{marker}" then
                            set found to w
                            exit repeat
                        end if
                    end if
                end try
            end repeat
            if found is missing value then return "WINDOW_LOST"
            {raise_line}
            set frontmost to true
            delay 0.2
            return "OK: " & (value of attribute "AXTitle" of window 1)
        end tell'''

    def is_alive(self, handle: WindowHandle) -> bool:
        out = self._osascript(self._find_script(handle, raise_it=False))
        return out.startswith("OK")

    def refocus(self, handle: WindowHandle, retries: int = 3) -> bool:
        """Bring the remembered window to front; True when verified.
        Retries because a freshly created window may not be in the AX tree
        immediately."""
        for attempt in range(retries):
            out = self._osascript(self._find_script(handle, raise_it=True))
            if out.startswith("OK"):
                return True
            time.sleep(0.6)
        return False

    def count_incognito(self, handle: WindowHandle) -> int:
        script = f'''
        tell application "System Events" to tell process "{handle.app}"
            set n to 0
            repeat with w in windows
                try
                    if (value of attribute "AXTitle" of w) contains "(Incognito)" then
                        set n to n + 1
                    end if
                end try
            end repeat
            return n as string
        end tell'''
        try:
            return int(self._osascript(script).strip() or 0)
        except ValueError:
            return -1

    def minimize_everything_else(self, handle: WindowHandle) -> str:
        keep = handle.title_marker
        script = f'''
        tell application "System Events"
            set n to 0
            repeat with p in (application processes whose visible is true and background only is false)
                try
                    repeat with w in windows of p
                        try
                            set t to ""
                            try
                                set t to value of attribute "AXTitle" of w
                            end try
                            if t does not contain "{keep}" then
                                set value of attribute "AXMinimized" of w to true
                                set n to n + 1
                            end if
                        end try
                    end repeat
                end try
            end repeat
            return "minimised " & n
        end tell'''
        return self._osascript(script)
