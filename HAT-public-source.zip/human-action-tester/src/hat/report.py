"""Test execution report generator (docx).

Builds the Human Action Tester execution document:
  - Page 1: test case identification block
  - For every step: one page with a facts table (action / input / expected /
    actual / verdict / evidence) and one page with the full-width screenshot
  - Final page: execution summary with the overall verdict

The document is deliberately self-contained: a person scrolling through it can
"replay" the test, and a replay driver can re-execute the test from it.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

VERDICT_COLORS = {
    "PASS": RGBColor(0x1E, 0x7E, 0x34),
    "FAIL": RGBColor(0xC0, 0x39, 0x2B),
    "INCONCLUSIVE": RGBColor(0xB2, 0x6A, 0x00),
}
VERDICT_SHADES = {
    "PASS": "E2F0E4",
    "FAIL": "FBE4E0",
    "INCONCLUSIVE": "FFF3D9",
}
ACCENT = RGBColor(0x0B, 0x5A, 0x64)


from .session import format_duration


def _total_execution_time(payload: dict):
    """Honest fallback chain: measured total → sum of step durations →
    test_case started/finished window → None (not measured)."""
    value = payload.get("total_duration_s")
    if isinstance(value, (int, float)) and value >= 0:
        return float(value)
    steps = payload.get("steps", [])
    durations = [s.get("duration_s") for s in steps]
    if durations and all(isinstance(d, (int, float)) for d in durations):
        return float(sum(durations))
    tc = payload.get("test_case", {})
    started, finished = tc.get("started", ""), tc.get("finished", "")
    for parser in (_parse_hhmm, _parse_iso_dt):
        t0, t1 = parser(started), parser(finished)
        if t0 and t1:
            delta = (t1 - t0).total_seconds()
            if delta < 0:            # crossed midnight (HH:MM only)
                delta += 24 * 3600
            return delta
    return None


def _parse_hhmm(text: str):
    import re
    m = re.match(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$", text.strip())
    if not m:
        return None
    from datetime import datetime
    h, mi = int(m.group(1)), int(m.group(2))
    sec = int(m.group(3) or 0)
    return datetime(1900, 1, 1, h, mi, sec)


def _parse_iso_dt(text: str):
    from datetime import datetime
    try:
        return datetime.fromisoformat(text.strip())
    except (ValueError, TypeError):
        return None


def _shade(cell, hex_fill: str) -> None:
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_fill)
    tcPr.append(shd)


def _cell_text(cell, text: str, bold: bool = False, color=None, size=10):
    cell.text = ""
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color
    return p


def _label_table(doc: Document, pairs, width_label=1.7, width_value=4.5):
    table = doc.add_table(rows=len(pairs), cols=2)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (label, value) in enumerate(pairs):
        _cell_text(table.rows[i].cells[0], label, bold=True, size=10)
        _cell_text(table.rows[i].cells[1], value, size=10)
        table.rows[i].cells[0].width = Inches(width_label)
        table.rows[i].cells[1].width = Inches(width_value)
    _set_table_margins(table)
    return table


def _set_table_margins(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    margins = OxmlElement("w:tblCellMar")
    for side in ("top", "left", "bottom", "right"):
        node = OxmlElement(f"w:{side}")
        node.set(qn("w:w"), "80")
        node.set(qn("w:type"), "dxa")
        margins.append(node)
    tblPr.append(margins)


def build_report(session: dict, screenshot_dir: Path, out_path: Path) -> Path:
    doc = Document()

    # base style
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10.5)
    style.paragraph_format.space_after = Pt(6)

    for section in doc.sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.8)
        section.left_margin = Inches(0.9)
        section.right_margin = Inches(0.9)

    tc = session["test_case"]
    steps = session["steps"]

    # ---------- Page 1: identification ----------
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = title.add_run("Test Execution Report")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = ACCENT

    sub = doc.add_paragraph()
    srun = sub.add_run(f"{tc['id']} — {tc['title']}")
    srun.font.size = Pt(14)
    srun.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    doc.add_paragraph()
    id_pairs = [
        ("Test case ID", tc["id"]),
        ("Title", tc["title"]),
    ]
    if tc.get("mode"):
        id_pairs.append(("Mode", tc["mode"]))
    id_pairs += [
        ("Target", tc.get("target", "")),
        ("Browser", tc.get("browser", "")),
        ("Machine", tc.get("machine", "")),
        ("Executed by", tc.get("executed_by", "")),
        ("Data row", tc.get("data_row", "")),
        ("Date", f"{tc.get('date', '')}  {tc.get('started', '')}–{tc.get('finished', '')}".strip()),
        ("Steps planned", str(len(steps))),
    ]
    _label_table(doc, id_pairs)
    doc.add_paragraph()
    note = doc.add_paragraph()
    nrun = note.add_run(
        "How to read this report: every step has two pages — a facts page "
        "(what was done, what was expected, what actually happened) followed "
        "by a full-size screenshot taken right after the action. Scrolling "
        "the document replays the test visually. The last page contains the "
        "execution summary and the overall verdict."
    )
    nrun.italic = True
    nrun.font.size = Pt(9.5)
    nrun.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    # ---------- steps: 2 pages each ----------
    for step in steps:
        doc.add_page_break()

        head = doc.add_paragraph()
        hrun = head.add_run(f"Step {step['n']} — {step['title']}")
        hrun.bold = True
        hrun.font.size = Pt(15)
        hrun.font.color.rgb = ACCENT

        desc = doc.add_paragraph()
        desc.add_run(step.get("description") or step.get("action", "")).italic = True

        rows = [
            ("Action (human)", step["action"]),
            ("Input", step["input"]),
            ("Expected result", step["expected"]),
            ("Actual result", step["actual"]),
            ("Evidence", step["evidence"]),
            ("Duration", format_duration(step.get("duration_s"))),
            ("Attempts", str(step.get("attempts") or "—")),
            ("Verdict", step["verdict"]),
        ]
        table = doc.add_table(rows=len(rows), cols=2)
        table.style = "Table Grid"
        for i, (label, value) in enumerate(rows):
            cells = table.rows[i].cells
            _cell_text(cells[0], label, bold=True, size=10)
            if label == "Verdict":
                verdict = value.upper()
                color = VERDICT_COLORS.get(verdict, RGBColor(0, 0, 0))
                _cell_text(cells[1], verdict, bold=True, color=color, size=11)
                _shade(cells[1], VERDICT_SHADES.get(verdict, "FFFFFF"))
                _shade(cells[0], VERDICT_SHADES.get(verdict, "FFFFFF"))
            else:
                _cell_text(cells[1], value, size=10)
            cells[0].width = Inches(1.6)
            cells[1].width = Inches(4.6)
        _set_table_margins(table)

        # screenshot page
        doc.add_page_break()
        cap = doc.add_paragraph()
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        crun = cap.add_run(f"Step {step['n']} — screen after action")
        crun.bold = True
        crun.font.size = Pt(11)

        img = screenshot_dir / step["screenshot"]
        if step["screenshot"] and img.is_file():
            doc.add_picture(str(img), width=Inches(6.45))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        else:
            missing = doc.add_paragraph()
            missing.add_run(f"[screenshot missing: {step['screenshot']}]").italic = True

    # ---------- final page: summary ----------
    doc.add_page_break()
    shead = doc.add_paragraph()
    shrun = shead.add_run("Execution Summary")
    shrun.bold = True
    shrun.font.size = Pt(18)
    shrun.font.color.rgb = ACCENT

    st = doc.add_table(rows=len(steps) + 1, cols=5)
    st.style = "Table Grid"
    header = st.rows[0]
    for j, text in enumerate(("Step", "Title", "Verdict", "Duration", "Evidence ref")):
        _cell_text(header.cells[j], text, bold=True, size=10)
        _shade(header.cells[j], "D9E7E9")
    for i, step in enumerate(steps, start=1):
        verdict = step["verdict"].upper()
        cells = st.rows[i].cells
        _cell_text(cells[0], str(step["n"]), size=10)
        _cell_text(cells[1], step["title"], size=10)
        _cell_text(cells[2], verdict, bold=True,
                   color=VERDICT_COLORS.get(verdict), size=10)
        _cell_text(cells[3], format_duration(step.get("duration_s")), size=10)
        _cell_text(cells[4], step["screenshot"], size=9)
    for row in st.rows:
        row.cells[0].width = Inches(0.5)
        row.cells[1].width = Inches(2.9)
        row.cells[2].width = Inches(1.1)
        row.cells[3].width = Inches(0.9)
        row.cells[4].width = Inches(1.5)
    _set_table_margins(st)

    doc.add_paragraph()
    passed = sum(1 for s in steps if s["verdict"].upper() == "PASS")
    failed = sum(1 for s in steps if s["verdict"].upper() == "FAIL")
    inconc = len(steps) - passed - failed
    stats = doc.add_paragraph()
    stats.add_run(
        f"{len(steps)} steps executed: {passed} passed, {failed} failed, "
        f"{inconc} inconclusive."
    ).bold = True

    total = _total_execution_time(session)
    if total is not None:
        total_p = doc.add_paragraph()
        trun = total_p.add_run(f"Total execution time: {format_duration(total)}")
        trun.bold = True
        trun.font.size = Pt(12)

    overall = session.get("overall_verdict", "INCONCLUSIVE").upper()
    verdict_p = doc.add_paragraph()
    vrun = verdict_p.add_run(f"OVERALL VERDICT: {overall}")
    vrun.bold = True
    vrun.font.size = Pt(16)
    vrun.font.color.rgb = VERDICT_COLORS.get(overall, RGBColor(0, 0, 0))
    _shade_after(verdict_p, VERDICT_SHADES.get(overall, "FFFFFF"))

    summ = doc.add_paragraph()
    summ.add_run(session.get("summary", "")).italic = True

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    return out_path


def _shade_after(paragraph, hex_fill: str) -> None:
    pPr = paragraph._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_fill)
    pPr.append(shd)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("session", type=Path, help="session JSON recorded by the runner")
    ap.add_argument("screenshots", type=Path, help="directory with step screenshots")
    ap.add_argument("--out", type=Path, required=True, help="output .docx path")
    args = ap.parse_args()
    session = json.loads(args.session.read_text())
    out = build_report(session, args.screenshots, args.out)
    print(f"report written: {out}")


if __name__ == "__main__":
    main()
