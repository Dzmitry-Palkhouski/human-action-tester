"""Datasets, data dictionary, placeholder resolution and masking.

The data dictionary is what teaches the LLM how to read and use the CSV/XLSX
files: every column has a role (input/expected/meta), a description, a format
and an example. Roles also drive masking: sensitive values never reach the
report in clear text.
"""
from __future__ import annotations

import csv
import os
import re
from dataclasses import dataclass
from pathlib import Path

PLACEHOLDER_RE = re.compile(r"\$\{(\w+)\.(\w+)\}")
# ${keychain.SERVICE} or ${keychain.SERVICE.ACCOUNT} — resolved from the macOS
# keychain at EXECUTION time; reports/cards only ever show a masked label.
KEYCHAIN_RE = re.compile(r"\$\{keychain\.([\w-]+)(?:\.([\w-]+))?\}")
# ${random.email} / ${random.password} — throwaway values generated at run time
RANDOM_EMAIL_RE = re.compile(r"\$\{random\.email\}")
RANDOM_PASSWORD_RE = re.compile(r"\$\{random\.password\}")
SELECTION_RE = re.compile(r"""^(\w+)\s*==\s*["']([^"']*)["']$""")
SENSITIVE_HINTS = ("password", "pin", "token", "secret", "credential")


def random_email() -> str:
    import uuid
    return f"qa.bot+{uuid.uuid4().hex[:10]}@example.com"


def random_password() -> str:
    import uuid
    return "Qa!" + uuid.uuid4().hex[:10]   # 13 chars, mixed


@dataclass(frozen=True)
class ColumnSpec:
    dataset: str
    column: str
    role: str          # input | expected | meta
    description: str
    format: str
    example: str


class DataDictionary:
    def __init__(self, specs: list[ColumnSpec]):
        self.specs = specs
        self._by_column = {s.column: s for s in specs}

    @classmethod
    def load(cls, path: Path) -> "DataDictionary":
        with open(path, newline="", encoding="utf-8") as fh:
            rows = csv.DictReader(fh)
            specs = [ColumnSpec(
                dataset=(r.get("dataset") or "").strip(),
                column=(r.get("column") or "").strip(),
                role=(r.get("role") or "meta").strip().lower(),
                description=(r.get("description") or "").strip(),
                format=(r.get("format") or "").strip(),
                example=(r.get("example") or "").strip(),
            ) for r in rows]
        return cls(specs)

    def spec(self, column: str) -> ColumnSpec | None:
        return self._by_column.get(column)

    def is_sensitive(self, column: str) -> bool:
        spec = self.spec(column)
        text = f"{column} {spec.description if spec else ''}".lower()
        return any(h in text for h in SENSITIVE_HINTS)

    def prompt_block(self) -> str:
        """Render the dictionary as the textual interpretation passed to the LLM."""
        lines = ["Data dictionary (how to read and use the dataset):"]
        for s in self.specs:
            lines.append(
                f"- {s.dataset}.{s.column}: role={s.role}; format={s.format}; "
                f"{s.description} Example: {s.example}"
            )
        return "\n".join(lines)


def load_dataset(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


def select_row(rows: list[dict], selection: str | None) -> dict:
    if not rows:
        raise ValueError("dataset is empty")
    if not selection:
        return rows[0]
    m = SELECTION_RE.match(selection.strip())
    if not m:
        raise ValueError(f"unsupported data_selection syntax: {selection!r}")
    key, value = m.group(1), m.group(2)
    for row in rows:
        if row.get(key, "").strip() == value:
            return row
    raise ValueError(f"no dataset row where {key} == {value!r}")


def mask_value(value: str) -> str:
    return "•" * len(value) if value else ""


def _keychain_cmd(service: str, account: str | None) -> list[str]:
    cmd = ["security", "find-generic-password", "-s", service]
    if account:
        cmd += ["-a", account]
    return cmd + ["-w"]


def keychain_lookup(service: str, account: str | None = None) -> str | None:
    """Executor-side helper: read a credential from the macOS keychain.

    Called at execution time only — resolved values live in the executor's
    memory for the duration of one `had type` and are never written to any
    artifact. Returns None when the item does not exist (the flow keeps the
    placeholder visible so the gap is obvious instead of silently empty).
    """
    import subprocess
    r = subprocess.run(_keychain_cmd(service, account),
                       capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None


def mask_keychain_placeholders(text: str) -> str:
    """Replace ${keychain.*} with a masked label for cards/sessions/reports.

    The label keeps enough information for the operator ("read this from
    keychain service X, account Y") and leaks nothing.
    """
    def sub(m):
        service, account = m.group(1), m.group(2)
        where = f"{service}/{account}" if account else service
        return f"•••••••• (keychain {where})"
    return KEYCHAIN_RE.sub(sub, text)


def resolve(text: str, meta: dict, row: dict, env: dict | None = None) -> str:
    env = env or {}
    text = RANDOM_EMAIL_RE.sub(random_email(), text)
    text = RANDOM_PASSWORD_RE.sub(random_password(), text)

    def sub(m):
        scope, key = m.group(1), m.group(2)
        if scope == "meta":
            return str(meta.get(key, m.group(0)))
        if scope == "row":
            return str(row.get(key, m.group(0)))
        if scope == "env":
            return str(env.get(key, m.group(0)))
        return m.group(0)

    return PLACEHOLDER_RE.sub(sub, text)


def resolve_step(step_fields: dict, meta: dict, row: dict,
                 dictionary: DataDictionary | None = None) -> dict:
    """Resolve placeholders in every field and mask sensitive input values.

    Masking has two layers:
      1. keychain placeholders never resolve in the report path — they become
         masked labels (the executor reads the real value from the keychain
         at execution time);
      2. any sensitive dataset column's concrete value found in a field is
         replaced by dots of the same length.
    """
    resolved = {k: resolve(mask_keychain_placeholders(v), meta, row)
                for k, v in step_fields.items()}
    if dictionary:
        for col, value in row.items():
            if value and dictionary.is_sensitive(col):
                for k, text in resolved.items():
                    if value in text:
                        resolved[k] = text.replace(value, mask_value(value))
    return resolved
