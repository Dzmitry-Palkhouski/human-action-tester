"""Tolerant parser for `.flow.md` test flow files (see docs/02-test-flow-format.md)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

STEP_RE = re.compile(r"^##\s+Step\s+(\d+)\s*[—–-]\s*(.+?)\s*$", re.M)
BULLET_RE = re.compile(r"^-\s+\*\*(.+?):?\*\*:?\s*(.+)$")


@dataclass
class Step:
    n: int
    title: str
    fields: dict = field(default_factory=dict)  # action/input/expected/note

    @property
    def action(self) -> str:
        return self.fields.get("action", "")

    @property
    def expected(self) -> str:
        return self.fields.get("expected", "")

    @property
    def input(self) -> str:
        return self.fields.get("input", "")

    @property
    def max_attempts(self) -> int | None:
        v = self.fields.get("max attempts")
        try:
            return int(v) if v else None
        except (TypeError, ValueError):
            return None


@dataclass
class ExploreGoal:
    """Simplified (goal-driven) flow: description + start + end criteria.

    The executor navigates the application on its own; only the successful
    path is distilled into documented test steps."""
    description: str = ""
    start: str = ""
    end_raw: str = ""
    criteria: list = field(default_factory=list)  # success criteria bullets
    notes: str = ""                                # executor guidance


@dataclass
class Flow:
    meta: dict
    steps: list
    path: Path | None = None
    goal: ExploreGoal | None = None

    @property
    def max_attempts(self) -> int:
        """Attempts budget per step: after N unreached attempts the step is
        recorded FAIL and the executor moves on. Never loop."""
        try:
            return int(self.meta.get("max_attempts", 3))
        except (TypeError, ValueError):
            return 3

    @property
    def mode(self) -> str:
        """scripted = step-by-step instructions; explore = goal-driven."""
        explicit = self.meta.get("mode")
        if explicit:
            return explicit.strip().lower()
        if self.steps:
            return "scripted"
        if self.goal:
            return "explore"
        return "scripted"

    @property
    def id(self) -> str:
        return self.meta.get("id", "UNKNOWN")

    @property
    def title(self) -> str:
        return self.meta.get("title", "")


def _parse_front_matter(text: str) -> tuple[dict, str]:
    meta = {}
    body = text
    if text.lstrip().startswith("---"):
        parts = text.lstrip().split("\n---", 2)
        if len(parts) >= 2:
            for line in parts[0][3:].splitlines():
                line = line.strip()
                if not line or ":" not in line:
                    continue
                key, _, value = line.partition(":")
                meta[key.strip()] = value.strip()
            rest = parts[1]
            body = rest[1:] if rest.startswith("\n") else rest
    return meta, body


def _parse_goal(body: str) -> ExploreGoal | None:
    """Extract Description/Start/End sections (goal mode). Returns None when
    none of them are present (pure scripted flow)."""
    sections: dict[str, str] = {}
    matches = list(re.finditer(r"^##\s+([^\n]+)\s*$", body, re.M))
    for i, m in enumerate(matches):
        name = m.group(1).strip()
        if STEP_RE.match(f"## {name}"):
            continue
        key = re.split(r"[—–-]", name)[0].strip().lower()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        sections.setdefault(key, body[start:end].strip())
    if not any(k in sections for k in ("description", "start", "end",
                                       "success criteria")):
        return None
    end_text = sections.get("end") or sections.get("success criteria") or ""
    criteria = [ln.lstrip("-").strip()
                for ln in end_text.splitlines() if ln.strip().startswith("-")]
    return ExploreGoal(
        description=sections.get("description", ""),
        start=sections.get("start", ""),
        end_raw=end_text,
        criteria=[c for c in criteria if c],
        notes=sections.get("notes") or sections.get("executor notes", ""),
    )


def parse_flow(text: str, path: Path | None = None) -> Flow:
    meta, body = _parse_front_matter(text)
    steps = []
    matches = list(STEP_RE.finditer(body))
    for i, m in enumerate(matches):
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        chunk = body[start:end]
        fields = {}
        for line in chunk.splitlines():
            line = line.strip()
            if not line.startswith("-"):
                continue
            bm = BULLET_RE.match(line)
            if bm:
                fields[bm.group(1).strip().lower().rstrip(":")] = bm.group(2).strip()
        steps.append(Step(n=int(m.group(1)), title=m.group(2).strip(), fields=fields))
    steps.sort(key=lambda s: s.n)
    return Flow(meta=meta, steps=steps, path=path, goal=_parse_goal(body))


def load_flow(path: Path) -> Flow:
    return parse_flow(Path(path).read_text(encoding="utf-8"), Path(path))
