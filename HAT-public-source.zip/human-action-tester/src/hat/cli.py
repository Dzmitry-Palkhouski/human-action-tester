"""Operator CLI for the Human Action Tester.

`hat execute` is operator-assisted by design: it prepares the session skeleton
and prints one operator card per step — the exact instructions the LLM (or a
human) follows while driving the machine. After the run, the operator's
observations are recorded into the session JSON (directly or via `hat record`),
and `hat report` produces the Word document.

Usage:
  python3 -m hat.cli execute --flow flows/x.flow.md --out-dir reports/run1
  python3 -m hat.cli record  --session reports/run1/x.session.json \
      --step 2 --verdict PASS --actual "..." --screenshot shot2.png
  python3 -m hat.cli report  --session reports/run1/x.session.json \
      --shots reports/run1/screenshots --out reports/run1/report.docx
  python3 -m hat.cli replay  --baseline reports/run1/x.session.json \
      --session reports/run2/x.session.json
  python3 -m hat.cli plan    --flow flows/x.flow.md
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import data as data_mod
from . import replay as replay_mod
from .driver import BROWSERS, DryRunDriver
from .flow import load_flow
from .report import build_report
from .session import Session, StepRecord

EXECUTOR_ID = ("Human Action Driver: LLM + OS-level keyboard/mouse events "
               "(CGEvent) + screenshot vision loop. No Selenium, no Playwright, "
               "no WebDriver, no CDP, no browser extension.")


def _explore_brief(flow, goal, row, dictionary) -> str:
    def clean(text: str) -> str:
        text = data_mod.mask_keychain_placeholders(text)
        return data_mod.resolve(text, flow.meta, row)
    criteria = "\n".join(f"  [{i}] {clean(c)}"
                         for i, c in enumerate(goal.criteria, 1)) or "  (none written)"
    notes = (f"\nEXECUTOR NOTES:\n{clean(goal.notes)}\n"
             if goal.notes.strip() else "")
    return f"""
━━━ EXPLORATION BRIEF — {flow.id}: {flow.title} (goal-driven mode) ━━━
MISSION:  {clean(goal.description) or '(none written)'}
START:    {clean(goal.start) or '(none written)'}
SUCCESS:  all of the following hold at the end state:
{criteria}
{notes}

NAVIGATION POLICY:
  - You choose the path through the application: observe (screenshot), decide
    one action, act, verify, repeat — like a person exploring a new app.
  - ATTEMPTS: max 3 attempts to reach any desired state (default
    3, set `max_attempts` in the flow front matter to change). After that,
    record FAIL for the goal and move on. Endless retrying is forbidden.
  - Budget: stop and record INCONCLUSIVE after ~30 actions without success.
  - Dead ends are normal: backtrack and try another route. They are NOT
    documented as test steps.

DISTILLATION (only the successful path becomes the report):
  - When the end state is reached, review your successful actions and segment
    them by user intention (e.g. "open login page", "enter credentials",
    "submit", "verify dashboard") — each segment becomes one test step.
  - Record each segment with: hat record --add --title "..." --action "..." \\
        --input "..." --expected "..." --verdict PASS --actual "..." \\
        --screenshot shotN.png   (screenshot from that moment of the run)
  - Expected comes from the success criteria; actual from what you saw.
  - If the goal is NOT reached: record the attempt as one step titled
    "Reach <goal>" with verdict FAIL (or INCONCLUSIVE) and the last
    screenshot, then record the remaining criteria as missing.
SECRETS:  values shown as dots live in the dataset/keychain; read them at
          execution time — briefs, sessions and reports never carry them.
"""


def _prepare(flow_path: Path, data_dir: Path | None):
    flow = load_flow(flow_path)
    base = flow.path.parent if flow.path else Path(".")
    dictionary = None
    row = {}
    dataset_rel = flow.meta.get("dataset")
    if dataset_rel:
        dataset_path = (data_dir / Path(dataset_rel).name) if data_dir else base / dataset_rel
        rows = data_mod.load_dataset(dataset_path)
        row = data_mod.select_row(rows, flow.meta.get("data_selection"))
        dict_rel = flow.meta.get("data_dictionary")
        if dict_rel:
            dict_path = (data_dir / Path(dict_rel).name) if data_dir else base / dict_rel
            dictionary = data_mod.DataDictionary.load(dict_path)
    return flow, row, dictionary


def cmd_execute(args) -> int:
    flow, row, dictionary = _prepare(Path(args.flow), Path(args.data_dir) if args.data_dir else None)
    browser = args.browser or flow.meta.get("browser") or "chrome"
    if browser not in BROWSERS:
        print(f"unknown browser {browser!r}; known: {sorted(BROWSERS)}",
              file=sys.stderr)
        return 2
    app = BROWSERS[browser]["app"]
    stage_card = f"""
━━━ STAGE 0 — Prepare the stage ({browser}) ━━━ RUN:      driver.prepare_stage("{browser}")
          (= minimise ALL windows of every visible app; activate {app};
          open ONE fresh incognito window at fixed bounds)
VERIFY:   full-screen screenshot shows EXACTLY ONE window — the new {app}
          window at the known bounds. No exceptions: if anything else is
          visible, fix Stage 0 before touching anything. Then proceed to Step 1.
"""
    steps = []
    cards = []
    for step in flow.steps:
        resolved = data_mod.resolve_step(step.fields, flow.meta, row, dictionary)
        rec = StepRecord(n=step.n, title=step.title,
                         action=resolved.get("action", ""),
                         input=resolved.get("input", ""),
                         expected=resolved.get("expected", ""))
        steps.append(rec)
        cards.append(f"""
━━━ OPERATOR CARD — Step {step.n}: {step.title} ━━━
DO:       {rec.action}
INPUT:    {rec.input}
EXPECTED: {rec.expected}
NOTE:     {resolved.get('note', '-')}
ATTEMPTS: {flow.max_attempts if step.max_attempts is None else step.max_attempts} maximum to reach the desired state on this page. After that many
          unreached attempts, record the step FAIL and move on — retrying
          endlessly is a protocol violation.
VERIFY:   take a screenshot after the action; compare what you see against
          EXPECTED; record verdict (PASS/FAIL/INCONCLUSIVE) with `hat record`.
SECRETS:  values shown as dots live in the dataset; read them from the CSV
          at execution time — cards, sessions and reports never carry them.
""")
    session = Session(test_case={
        "id": flow.meta.get("id", "UNKNOWN"),
        "title": flow.meta.get("title", ""),
        "target": flow.meta.get("target", ""),
        "browser": f"{browser} ({app}, real profile, no automation flags)",
        "machine": flow.meta.get("machine", ""),
        "executed_by": EXECUTOR_ID,
        "data_row": (f"{Path(flow.meta.get('dataset', '')).name} "
                     f"row {row.get('row_id', '?')} "
                     f"(purpose={row.get('purpose', '?')})") if row else "-",
        "date": "", "started": "", "finished": "",
        **({"mode": "goal-driven (AI-navigated, successful path documented)"}
           if flow.mode == "explore" else {}),
    }, steps=steps)
    out_dir = Path(args.out_dir)
    shots = out_dir / "screenshots"
    shots.mkdir(parents=True, exist_ok=True)
    session_path = out_dir / f"{flow.id}.session.json"
    session.save(session_path)
    if dictionary:
        print(dictionary.prompt_block())
        print()
    if flow.mode == "explore" and flow.goal:
        print(_explore_brief(flow, flow.goal, row, dictionary))
    else:
        print(stage_card)
        print("\n".join(cards))
    print(f"session skeleton: {session_path}")
    print(f"screenshots dir : {shots}")
    return 0


def cmd_record(args) -> int:
    from .session import StepRecord as _SR, now_iso, parse_iso
    session = Session.load(Path(args.session))
    if args.add:
        # explore-mode distillation: append a discovered step
        n = max((s.n for s in session.steps), default=0) + 1
        s = _SR(n=n, title=args.title or f"step {n}",
                action=args.action or "", input=args.input or "",
                expected=args.expected or "")
        session.steps.append(s)
    else:
        s = next((x for x in session.steps if x.n == args.step), None)
    if s is None:
        print(f"no step {args.step} in session", file=sys.stderr)
        return 2
    if args.verdict:
        s.verdict = args.verdict.upper()
    if args.actual is not None:
        s.actual = args.actual
    if args.evidence is not None:
        s.evidence = args.evidence
    if args.screenshot is not None:
        s.screenshot = args.screenshot
    if args.attempts is not None:
        s.attempts = int(args.attempts)
    # timing: explicit --duration wins; otherwise wall-clock since the
    # previous step was recorded (session creation for the first step)
    if args.duration is not None:
        s.duration_s = float(args.duration)
    else:
        prev_stamps = [p.recorded_at for p in session.steps
                       if p.n < s.n and p.recorded_at]
        start = (parse_iso(max(prev_stamps)) if prev_stamps
                 else parse_iso(session.created_at))
        now = parse_iso(now_iso())
        if start and now and now >= start:
            s.duration_s = (now - start).total_seconds()
    s.recorded_at = now_iso()
    session.save(Path(args.session))
    dur = (f"{s.duration_s:.1f}s" if s.duration_s is not None else "n/a")
    print(f"step {s.n}: {s.verdict} in {dur}; "
          f"overall={session.overall_verdict} counts={session.counts()}")
    return 0






def cmd_run(args) -> int:
    """One command, end to end: stage0 -> steps (plan + perceive + verify,
    attempts-bounded) -> session -> report. Hosts (ZCode chat wrapper,
    Copilot CLI) either service host-file perceptions or configure the HTTP
    perceiver — the implementation is the same CLI either way."""
    import sys as _sys
    import time as _time
    from .perceiver import HostFilePerceiver, HttpVisionPerceiver
    from .report import build_report
    from .runner import RunEngine

    flow, row, dictionary = _prepare(Path(args.flow),
                                     Path(args.data_dir) if args.data_dir else None)
    browser = args.browser or flow.meta.get("browser") or "chrome"
    if _sys.platform == "win32":
        from .driver_win import WindowsDriver
        if browser == "edge-ie":
            driver = WindowsDriver(browser="edge", ie_mode=True)
        else:
            driver = WindowsDriver(browser=browser)
    else:
        from .driver_mac import MacDriver
        if browser == "edge-ie":
            sys.exit("--browser edge-ie is Windows-only (Edge IE-Mode flags)")
        driver = MacDriver(browser=browser)
    if args.perceiver == "host":
        perceiver = HostFilePerceiver(Path(args.out_dir),
                                      timeout_s=args.host_timeout)
    elif args.perceiver == "copilot":
        from .perceiver import CopilotCliPerceiver
        perceiver = CopilotCliPerceiver(model=args.model)
    else:
        perceiver = HttpVisionPerceiver(provider=args.provider,
                                        model=args.model)

    engine = RunEngine(flow, driver, perceiver, Path(args.out_dir), row=row,
                       dictionary=dictionary,
                       max_attempts=args.max_attempts,
                       plan_file=Path(args.plan) if args.plan else None,
                       keep_browser=args.keep_browser)
    print(f"run started: {flow.id} — {flow.title} "
          f"(perceiver={args.perceiver}, max_attempts={engine.max_attempts})")
    if args.perceiver == "host":
        print(f"HOST: service perceptions with: "
              f"python3 -m hat.cli perceive --run {args.out_dir} pending")
    try:
        session = engine.run()
    except Exception as e:  # interrupted/failed run still reports
        print(f"run aborted: {e}")
        session = engine.session
        session.summary = (session.summary + f" Run aborted: {e}").strip()
    # finish: anything still pending is INCONCLUSIVE, then report
    for s in session.steps:
        if s.verdict == "PENDING":
            s.verdict = "INCONCLUSIVE"
            s.actual = "Step not executed — run ended before this step completed"
    session.test_case["finished"] = _time.strftime("%H:%M")
    session.save(Path(args.out_dir) / f"{flow.id}.session.json")
    report = Path(args.out_dir) / f"{flow.id}_Report.docx"
    build_report(session.to_report_dict(),
                 Path(args.out_dir) / "screenshots", report)
    print(f"verdict: {session.overall_verdict} counts={session.counts()}")
    print(f"session: {Path(args.out_dir) / (flow.id + '.session.json')}")
    print(f"report : {report}")
    return 0 if session.overall_verdict == "PASS" else 1


def cmd_perceive(args) -> int:
    """Host helper: service HostFilePerceiver requests (chat wrapper loop)."""
    import glob
    import json as _json
    pdir = Path(args.run) / "perceive"
    if not pdir.exists():
        print("no perception dir (run not started with --perceiver host)")
        return 1
    if args.cmd == "pending":
        pending = []
        for req in sorted(glob.glob(str(pdir / "req-*.json"))):
            rid = Path(req).stem.replace("req-", "")
            if not (pdir / f"ans-{rid}.json").exists():
                pending.append(_json.loads(Path(req).read_text()))
        for r in pending:
            print(f"[{r['id']}] {r['question']}")
            print(f"      image: {r['image']}")
        if not pending:
            print("(none)")
        return 0
    if args.cmd == "answer":
        ans = pdir / f"ans-{args.id}.json"
        ans.write_text(_json.dumps({"id": args.id, "text": args.text}),
                       encoding="utf-8")
        print(f"answered {args.id}")
        return 0
    return 2


def cmd_finish(args) -> int:
    """Interrupted-session report: mark every unexecuted step INCONCLUSIVE,
    set the interruption note, and generate the report. A stopped session
    must still produce a test report."""
    session = Session.load(Path(args.session))
    marked = 0
    for s in session.steps:
        if s.verdict == "PENDING":
            s.verdict = "INCONCLUSIVE"
            s.actual = args.mark or "Step not executed — session interrupted before completion"
            marked += 1
    if args.note:
        session.summary = (session.summary + " " + args.note).strip()
    session.save(Path(args.session))
    counts = session.counts()
    print(f"finish: {marked} pending steps marked INCONCLUSIVE; "
          f"overall={session.overall_verdict} counts={counts}")
    if args.out:
        out = build_report(session.to_report_dict(), Path(args.shots) if args.shots else Path(args.session).parent / "screenshots", Path(args.out))
        print(f"report written: {out}")
    return 0


def cmd_report(args) -> int:
    session = Session.load(Path(args.session))
    out = build_report(session.to_report_dict(), Path(args.shots), Path(args.out))
    print(f"report written: {out}")
    return 0


def cmd_replay(args) -> int:
    baseline = Session.load(Path(args.baseline))
    replay = Session.load(Path(args.session))
    compares = replay_mod.compare(baseline, replay)
    print(replay_mod.format_table(compares))
    print()
    print("summary:", json.dumps(replay_mod.summary(compares)))
    if args.out:
        rep_session = Session(
            test_case={**replay.test_case,
                       "id": replay.test_case.get("id", "") + " (replay of " + baseline.test_case.get("id", "") + ")",
                       "title": "Replay verification — " + replay.test_case.get("title", "")},
            steps=[s for s in replay.steps],
            summary=("Replay vs baseline outcomes: " +
                     json.dumps(replay_mod.summary(compares))),
        )
        # annotate each step's evidence with the outcome
        by_n = {c.n: c for c in compares}
        for s in rep_session.steps:
            if s.n in by_n and s.done():
                s.evidence = (f"[{by_n[s.n].outcome} vs baseline "
                              f"{by_n[s.n].baseline_verdict}] " + s.evidence).strip()
        build_report(rep_session.to_report_dict(), Path(args.shots), Path(args.out))
        print(f"replay report: {args.out}")
    return 0


def cmd_plan(args) -> int:
    flow, row, dictionary = _prepare(Path(args.flow), Path(args.data_dir) if args.data_dir else None)
    drv = DryRunDriver()
    print(f"PLAN for {flow.id} — {flow.title}")
    if dictionary:
        print(dictionary.prompt_block())
    for step in flow.steps:
        resolved = data_mod.resolve_step(step.fields, flow.meta, row, dictionary)
        print(f"\nStep {step.n}: {step.title}")
        for k in ("action", "input", "expected", "note"):
            if resolved.get(k):
                print(f"  {k:9}: {resolved[k]}")
        print("  driver   : (the operator/LLM composes click/type/key sequences;")
        print("             example primitives below)")
        drv.click(0, 0)   # touch to show intent style
        drv.intents.pop()
    print("\n(dry run — no actions executed)")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="hat", description="Human Action Tester")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("execute", help="prepare session + operator cards")
    p.add_argument("--flow", required=True)
    p.add_argument("--data-dir", help="directory holding datasets/dictionary")
    p.add_argument("--browser",
                   help="override the flow's browser (chrome/edge/brave/safari)")
    p.add_argument("--out-dir", required=True)
    p.set_defaults(fn=cmd_execute)

    p = sub.add_parser("record", help="record a step outcome into the session")
    p.add_argument("--session", required=True)
    p.add_argument("--step", type=int,
                   help="existing step number (scripted mode)")
    p.add_argument("--add", action="store_true",
                   help="append a NEW discovered step (explore mode)")
    p.add_argument("--title", help="title for a step added with --add")
    p.add_argument("--action", help="action text for a step added with --add")
    p.add_argument("--input", help="input text for a step added with --add")
    p.add_argument("--expected",
                   help="expected text for a step added with --add")
    p.add_argument("--verdict", choices=["PASS", "FAIL", "INCONCLUSIVE"])
    p.add_argument("--actual")
    p.add_argument("--evidence")
    p.add_argument("--screenshot")
    p.add_argument("--duration", type=float,
                   help="explicit step duration in seconds (overrides "
                        "wall-clock measurement)")
    p.add_argument("--attempts", type=int,
                   help="attempts made to reach the desired state")
    p.set_defaults(fn=cmd_record)

    p = sub.add_parser("run", help="execute a flow end to end via the CLI runner")
    p.add_argument("--flow", required=True)
    p.add_argument("--data-dir")
    p.add_argument("--browser",
                   help="chrome/edge/brave/safari (macOS) | chrome/edge/ie (Windows)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--perceiver", choices=["host", "copilot", "http"],
                   default="host",
                   help="host: chat wrapper answers request files; "
                        "copilot: GitHub Copilot CLI (Sonnet 5.5 vision) — "
                        "no separate vision API; http: direct vision API")
    p.add_argument("--provider", default="openai",
                   help="openai | zai | anthropic (http perceiver)")
    p.add_argument("--model", default="gpt-4o-mini",
                   help="vision model id (http perceiver)")
    p.add_argument("--host-timeout", type=float, default=600.0,
                   help="seconds to wait for each host perception answer")
    p.add_argument("--max-attempts", type=int, default=None,
                   help="override flow max_attempts")
    p.add_argument("--plan", help="sidecar JSON plan file {step_n: [cmds]}")
    p.add_argument("--keep-browser", action="store_true",
                   help="skip teardown (debugging; default closes the "
                        "browser and removes the temp profile)")
    p.set_defaults(fn=cmd_run)

    p = sub.add_parser("perceive", help="host helper: service perception requests")
    p.add_argument("--run", required=True, help="run dir")
    p.add_argument("cmd", choices=["pending", "answer"])
    p.add_argument("--id", help="request id (for answer)")
    p.add_argument("--text", help="answer text (for answer)")
    p.set_defaults(fn=cmd_perceive)

    p = sub.add_parser("finish", help="finalise an interrupted session and write its report")
    p.add_argument("--session", required=True)
    p.add_argument("--note", help="interruption note recorded in the summary")
    p.add_argument("--mark", help="text for the actual-result of unexecuted steps")
    p.add_argument("--shots", help="screenshots dir if a report should be generated")
    p.add_argument("--out", help="report docx path")
    p.set_defaults(fn=cmd_finish)

    p = sub.add_parser("report", help="generate the docx report")
    p.add_argument("--session", required=True)
    p.add_argument("--shots", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_report)

    p = sub.add_parser("replay", help="compare replay session vs baseline")
    p.add_argument("--baseline", required=True)
    p.add_argument("--session", required=True)
    p.add_argument("--shots", help="screenshot dir, if --out report wanted")
    p.add_argument("--out", help="optional replay report docx path")
    p.set_defaults(fn=cmd_replay)

    p = sub.add_parser("plan", help="dry-run: show resolved steps, execute nothing")
    p.add_argument("--flow", required=True)
    p.add_argument("--data-dir")
    p.set_defaults(fn=cmd_plan)

    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
