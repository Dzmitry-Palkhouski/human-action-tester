"""Execution session recording — the replay contract."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

VERDICTS = ("PASS", "FAIL", "INCONCLUSIVE")
PENDING = "PENDING"


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def parse_iso(stamp: str) -> datetime | None:
    try:
        return datetime.fromisoformat(stamp)
    except (ValueError, TypeError):
        return None


def format_duration(seconds) -> str:
    """Human-readable duration; None → em dash (not measured)."""
    if seconds is None:
        return "—"
    seconds = float(seconds)
    if seconds < 0:
        return "—"
    if seconds < 60:
        return f"{seconds:.1f} s"
    total = int(seconds)
    m, s = divmod(total, 60)
    if m < 60:
        return f"{m} m {s:02d} s"
    h, m = divmod(m, 60)
    return f"{h} h {m:02d} m"


@dataclass
class StepRecord:
    n: int
    title: str
    description: str = ""              # one-line context shown under the title
    action: str = ""
    input: str = ""
    expected: str = ""
    actual: str = ""
    verdict: str = PENDING      # PENDING until the operator records an outcome
    evidence: str = ""
    screenshot: str = ""
    duration_s: float | None = None   # wall-clock of executing this step
    attempts: int = 0                 # attempts made to reach the desired state
    recorded_at: str = ""             # ISO timestamp of the record call

    def done(self) -> bool:
        return self.verdict in VERDICTS

    @classmethod
    def from_payload(cls, payload: dict) -> "StepRecord":
        """Tolerant loader: unknown keys from newer/older files are dropped."""
        keys = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in payload.items() if k in keys})


@dataclass
class Session:
    test_case: dict
    steps: list = field(default_factory=list)
    summary: str = ""
    created_at: str = field(default_factory=now_iso)

    @property
    def overall_verdict(self) -> str:
        verdicts = [s.verdict for s in self.steps]
        if not verdicts or PENDING in verdicts:
            return PENDING          # a run is not over until every step has a verdict
        if "FAIL" in verdicts:
            return "FAIL"
        if "INCONCLUSIVE" in verdicts:
            return "INCONCLUSIVE"
        return "PASS"

    def counts(self) -> dict:
        c = {"pass": 0, "fail": 0, "inconclusive": 0, "pending": 0}
        for s in self.steps:
            if s.verdict == "PASS":
                c["pass"] += 1
            elif s.verdict == "FAIL":
                c["fail"] += 1
            elif s.verdict == "INCONCLUSIVE":
                c["inconclusive"] += 1
            else:
                c["pending"] += 1
        return c

    # -- timing -------------------------------------------------------------
    @property
    def total_duration_s(self) -> float | None:
        """Total execution time, preferring measured per-step durations:
        if every recorded step has a duration, their sum IS the run; otherwise
        fall back to wall-clock from session creation to the last record."""
        done = [s for s in self.steps if s.done()]
        if done and all(s.duration_s is not None for s in done):
            return float(sum(s.duration_s for s in done))
        start = parse_iso(self.created_at)
        stamps = [s.recorded_at for s in self.steps if s.recorded_at]
        if start is None or not stamps:
            return None
        ends = [e for e in (parse_iso(s) for s in stamps) if e]
        if not ends:
            return None
        return (max(ends) - start).total_seconds()

    # -- serialisation ------------------------------------------------------
    def save(self, path: Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "test_case": self.test_case,
            "steps": [asdict(s) for s in self.steps],
            "overall_verdict": self.overall_verdict,
            "summary": self.summary,
            "created_at": self.created_at,
            "total_duration_s": self.total_duration_s,
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path

    @classmethod
    def load(cls, path: Path) -> "Session":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        steps = [StepRecord.from_payload(s) for s in payload.get("steps", [])]
        return cls(test_case=payload.get("test_case", {}), steps=steps,
                   summary=payload.get("summary", ""),
                   created_at=payload.get("created_at", ""))

    def to_report_dict(self) -> dict:
        """Shape consumed by hat.report.build_report."""
        return {
            "test_case": self.test_case,
            "steps": [asdict(s) for s in self.steps],
            "overall_verdict": self.overall_verdict,
            "summary": self.summary,
            "total_duration_s": self.total_duration_s,
        }
